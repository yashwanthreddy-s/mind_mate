# MindMate - AI Cognitive Gaming & Memory Assistance Platform

**Team Algo-X (SIH26003)**  
*A Mobile-First Progressive Web App (PWA) tailored for elderly dementia and mild cognitive impairment (MCI) patients and community healthcare workers in North Eastern India (NER).*

---

## 🌟 Key Highlights

- **Regional Cultural Grounding (NER)**: Games feature authentic North Eastern motifs—Assamese *Phulam Gamosa*, *Kaziranga Rhino*, *Bihu Japi & Dhol*, *Assam Tea*, Manipur's *Loktak Lake*, and Mizo traditional instruments.
- **Voice-First Accessibility**: Web Speech API integration with text-to-speech reading on every screen, voice commands (`"Play"`, `"Help"`, `"My Day"`, `"Family"`), 18px+ high-contrast typography, and 48px+ touch targets.
- **Pan-India Multilingual Support (26 Languages)**:
  - Assamese (অসমীয়া)
  - Bengali (বাংলা)
  - Bodo (बर’ / बड़ो)
  - Dogri (डोगरी)
  - English (English)
  - Garo (A·chik)
  - Gujarati (ગુજરાતી)
  - Hindi (हिंदी)
  - Kannada (ಕನ್ನಡ)
  - Kashmiri (کٲشُر / کشمیری)
  - Khasi (Ka Ktien Khasi)
  - Konkani (कोंकणी)
  - Maithili (मैथिली)
  - Malayalam (മലയാളം)
  - Manipuri / Meitei (মৈতৈলোন্)
  - Marathi (मराठी)
  - Mizo (Mizo ṭawng)
  - Nepali (नेपाली)
  - Odia (ଓଡ଼ିଆ)
  - Punjabi (ਪੰਜਾਬੀ)
  - Sanskrit (संस्कृतम्)
  - Santali (ᱥᱟᱱᱛᱟᱲᱤ / संताली)
  - Sindhi (سنڌي / सिंधी)
  - Tamil (தமிழ்)
  - Telugu (తెలుగు)
  - Urdu (اردو)
- **AI Cognitive Decline Scoring Engine**:
  - Rule-based cognitive health scoring (0–100) weighted by Memory (35%), Attention (25%), Orientation (20%), and Language (20%).
  - 14-day established baseline tracking.
  - Automatic decline alerts dispatched whenever rolling 7-day average drops by **>15%**.
- **Offline-First PWA**: Powered by Service Workers (`vite-plugin-pwa`) and local persistence (`localStorage` / IndexedDB). Web Audio API synthesizes all music and sound offline without external network dependencies.
- **ASHA Community Healthcare Worker Mode**: Multi-patient triage dashboard with color-coded status (Green, Amber, Red), quick home-visit logging, and 1-tap cloud synchronization.
- **One-Tap Clinical PDF Report**: Export clinical assessment reports formatted with patient history, baseline vs. 7-day trends, domain breakdown, and clinician recommendations using `jspdf`.

---

## 👥 3 Pre-Seeded Demo Accounts

1. **Elder Patient — Aita Nirmala Baruah (74 yrs, Tezpur, Assam)**
   - Diagnosis: Mild Cognitive Impairment (MCI)
   - Status: **RED (Decline Alert Triggered)**
   - 30 days of pre-seeded clinical data: Earlier 16 days baseline ~79.5/100, last 7 days dropping to 63.2/100 (**-20.5% drop**, triggering immediate alert!).
   - Caregiver: Son Pranjal Baruah.
2. **Elder Patient — Lalhmangaiha "Pu Zara" (78 yrs, Aizawl, Mizoram)**
   - Diagnosis: Early Alzheimer's
   - Status: **GREEN (Stable at 74.8/100)**
   - Caregiver: Daughter Lalrinsangi.
3. **Elder Patient — Bimola Devi (71 yrs, Imphal, Manipur)**
   - Diagnosis: Vascular Dementia
   - Status: **AMBER (Watch closely at 63.9/100, -7.4% fluctuation)**
   - Caregiver: Nephew Sanatomba Singh.

---

## 🎮 5 Cognitive Games with Regional Cultural Content

1. **Memory Card Match**: 4 to 12 card visual recall using Kaziranga rhino, Phulam Gamosa, Assam tea, Bihu Japi, and Loktak boat.
2. **Name the Picture / Object**: High-contrast illustrations with audio pronunciation and regional names.
3. **Folk Rhythm Sequence Recall**: Simon-style rhythmic sequence game using synthesized Bihu Dhol, Buffalo Horn Pepa, Tokari lute, and Mountain flute.
4. **Orientation Quiz**: Gentle orientation questions regarding time of day, day of week, hometown, and family recognition.
5. **Folk Music / Instrument Recall**: Auditory memory stimulation via synthesized folk instrument tones.

---

## 🧭 Step-by-Step Demo Walkthrough

### Step 1: Patient Mode Experience
1. On the top navigation bar, ensure **Patient** mode is active (default).
2. Notice the high-contrast warm palette, large buttons, and Assamese greeting (`শুভ পুৱা, আইতা!`).
3. Click the **Voice (Mic)** button on top and say **"Play"** or **"My Day"** (or click the microphone). Click the **Listen** speaker button to hear the page read aloud.
4. Switch language from the top-right dropdown (test English, Assamese, Hindi, Manipuri, or Mizo).
5. Click **Play Games** → Play **Memory Match** or **Folk Rhythm Sequence**. Notice the encouraging audio cues, confetti, and calculated score.
6. Click **My Day & Medicine** → Mark morning tea and blood pressure medicine as taken.
7. Click **My Family Album** → Tap any family portrait to hear their voice note and relation.
8. Click the red **SOS** button on the top right → Experience the calm reassurance modal, breathing guide, and 1-tap call to caregiver.

### Step 2: Caregiver Dashboard & AI Decline Detection
1. In the top bar, switch role to **Caregiver**.
2. Notice the prominent **Red AI Decline Alert**:
   > *"Significant 7-Day Cognitive Drop Detected (-20.5% Drop). 7-day average score (63.2) dropped below 14-day baseline (79.5)."*
3. View the interactive **Recharts Trajectory Chart**:
   - Toggle between **Last 7 Days** and **Full 30 Days**.
   - Note the dashed baseline line at 79.5 and the red decline threshold line at 67.5 (-15%).
4. Inspect the **Cognitive Domain Performance** bar chart (Memory, Attention, Orientation, Language).
5. Toggle **Telehealth Consent** on/off.
6. Click **Download Clinical PDF Report** → Instantly generates and downloads a clean, multi-section clinical PDF report ready for doctor review.

### Step 3: ASHA Health Worker Mode & Offline Sync
1. In the top bar, switch role to **ASHA**.
2. View the triage patient cards color-coded by clinical priority:
   - **Nirmala Baruah** (Red - Decline Alert)
   - **Bimola Devi** (Amber - Watch)
   - **Lalhmangaiha** (Green - Stable)
3. Filter by triage category (Red / Amber / Green) or search by district.
4. Fill out the **Log ASHA Home Visit Note** form (select mood, medication adherence, and clinical observation) → Click **Save Visit Note**.
5. Click **Sync Offline Data** → Simulates cloud synchronization with progress spinner and sync timestamp.

---

## 🛠️ Technology Stack

- **Framework**: React 19 + TypeScript + Vite
- **Styling**: Tailwind CSS v4 with elderly-accessible tap targets and typography
- **Charts**: Recharts
- **PDF Generation**: jsPDF
- **Offline PWA**: `vite-plugin-pwa` + Service Worker + IndexedDB/LocalStorage
- **Audio & Speech**: HTML5 Web Audio API synthesizer + Web Speech API (Synthesis & Recognition)
- **Icons**: Lucide React
- **Celebration Effects**: Canvas-confetti
