export type Role = 'patient' | 'caregiver' | 'asha';

export type LanguageCode =
  | 'en'
  | 'hi'
  | 'as'
  | 'bn'
  | 'te'
  | 'ta'
  | 'mr'
  | 'gu'
  | 'kn'
  | 'ml'
  | 'pa'
  | 'or'
  | 'ur'
  | 'mni'
  | 'lus'
  | 'brx'
  | 'mai'
  | 'sa'
  | 'ks'
  | 'ne'
  | 'gom'
  | 'sd'
  | 'doi'
  | 'sat'
  | 'kha'
  | 'grt';

export interface EmergencyContact {
  name: string;
  relation: string;
  phone: string;
}

export interface RoutineItem {
  id: string;
  time: string;
  title: string;
  description: string;
  category: 'medicine' | 'meal' | 'activity' | 'rest';
  completed: boolean;
  iconName: string;
}

export interface FamilyMember {
  id: string;
  name: string;
  relation: string;
  location: string;
  phone: string;
  photoUrl: string;
  voiceNote: string;
  keyMemory: string;
}

export interface PatientProfile {
  id: string;
  name: string;
  nickname: string;
  age: number;
  gender: 'Female' | 'Male' | 'Other';
  location: string;
  district: string;
  state: string;
  language: LanguageCode;
  diagnosis: 'Mild Cognitive Impairment' | 'Early Alzheimer\'s' | 'Vascular Dementia' | 'Age-Associated Memory Impairment';
  status: 'green' | 'amber' | 'red';
  statusReason?: string;
  baselineScore: number; // 14-day baseline
  currentScore: number;
  scoreChangePct: number; // e.g., -18.5%
  avatarUrl: string;
  caregiver: {
    name: string;
    relation: string;
    phone: string;
    email: string;
  };
  emergencyContacts: EmergencyContact[];
  consentGiven: boolean;
  dailyRoutine: RoutineItem[];
  familyMembers: FamilyMember[];
  ashaNotes?: string[];
  lastScreeningDate: string;
}

export type GameType = 
  | 'memory_match' 
  | 'name_object' 
  | 'sequence_recall' 
  | 'orientation_quiz' 
  | 'folk_music';

export interface GameSessionResult {
  id: string;
  patientId: string;
  gameType: GameType;
  level: number;
  accuracy: number; // 0 - 100
  reactionTimeMs: number;
  errors: number;
  completed: boolean;
  timestamp: string;
  score: number;
}

export interface DailyCognitiveScore {
  date: string; // YYYY-MM-DD
  overallScore: number; // 0 - 100
  domainScores: {
    memory: number;      // weight: 35%
    attention: number;   // weight: 25%
    orientation: number; // weight: 20%
    language: number;    // weight: 20%
  };
  gamesPlayed: GameType[];
  averageReactionTimeMs: number;
}

export interface DeclineAlert {
  id: string;
  patientId: string;
  patientName: string;
  date: string;
  severity: 'amber' | 'red';
  title: string;
  description: string;
  baselineAvg: number;
  recentAvg: number;
  percentageDrop: number;
  affectedDomains: string[];
  recommendedAction: string;
  acknowledged: boolean;
}

export interface AshaVisitNote {
  id: string;
  patientId: string;
  patientName: string;
  date: string;
  ashaName: string;
  mood: 'Calm' | 'Cheerful' | 'Agitated' | 'Confused' | 'Withdrawn';
  medicationAdherence: 'Taken' | 'Missed' | 'Assisted';
  observation: string;
  synced: boolean;
}
