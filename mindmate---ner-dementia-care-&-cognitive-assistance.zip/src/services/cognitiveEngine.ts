import { GameType, GameSessionResult, DailyCognitiveScore, DeclineAlert, PatientProfile } from '../types';
import { StorageService } from './storage';

export interface CognitiveAnalysisResult {
  dailyScore: number;
  domainScores: {
    memory: number;
    attention: number;
    orientation: number;
    language: number;
  };
  baseline14DayAvg: number;
  recent7DayAvg: number;
  percentageChange: number;
  isDeclineTriggered: boolean;
  status: 'green' | 'amber' | 'red';
  suggestedLevel: number;
  insights: string[];
}

export class CognitiveEngine {
  /**
   * Weights for computing Daily Cognitive Health Score (0-100)
   */
  public static readonly DOMAIN_WEIGHTS = {
    memory: 0.35,      // Visual & associative recall
    attention: 0.25,   // Reaction time & sequence following
    orientation: 0.20, // Time, place & family familiarity
    language: 0.20,    // Naming & auditory comprehension
  };

  /**
   * Evaluates a completed game session into a normalized score (0-100)
   */
  public static calculateSessionScore(
    gameType: GameType,
    level: number,
    accuracy: number,
    reactionTimeMs: number,
    errors: number
  ): number {
    // Base score from accuracy
    let score = accuracy * 0.7;

    // Level multiplier bonus (higher level gives up to +15 pts)
    const levelBonus = (level - 1) * 3.5;
    score += levelBonus;

    // Reaction time factor (elderly baseline: 1500ms - 3500ms is standard)
    if (reactionTimeMs < 2000) {
      score += 10;
    } else if (reactionTimeMs < 3500) {
      score += 5;
    } else if (reactionTimeMs > 6000) {
      score -= 8;
    }

    // Error penalty (capped)
    const errorPenalty = Math.min(15, errors * 3);
    score -= errorPenalty;

    return Math.max(20, Math.min(100, Math.round(score)));
  }

  /**
   * Suggests next difficulty level (1-5) based on recent sessions
   */
  public static getAdaptiveLevel(recentAccuracy: number, recentReactionTimeMs: number, currentLevel: number): number {
    if (recentAccuracy >= 85 && recentReactionTimeMs < 2800) {
      return Math.min(5, currentLevel + 1);
    }
    if (recentAccuracy < 55) {
      return Math.max(1, currentLevel - 1);
    }
    return currentLevel;
  }

  /**
   * Comprehensive patient cognitive health analysis
   * Computes 14-day baseline, 7-day average, and triggers decline alert if drop > 15%
   */
  public static analyzePatient(patient: PatientProfile): CognitiveAnalysisResult {
    const scores = StorageService.getPatientScores(patient.id);

    if (scores.length === 0) {
      return {
        dailyScore: patient.currentScore,
        domainScores: { memory: 70, attention: 70, orientation: 70, language: 70 },
        baseline14DayAvg: patient.baselineScore,
        recent7DayAvg: patient.currentScore,
        percentageChange: 0,
        isDeclineTriggered: false,
        status: patient.status,
        suggestedLevel: 2,
        insights: ['Initial screening in progress.'],
      };
    }

    // Sort by date ascending
    const sorted = [...scores].sort((a, b) => a.date.localeCompare(b.date));

    // 14-Day Baseline: Use days 0..14 (or earliest 14 days in record)
    const baselineSlice = sorted.slice(0, Math.min(14, sorted.length));
    const baselineSum = baselineSlice.reduce((sum, s) => sum + s.overallScore, 0);
    const baseline14DayAvg = Number((baselineSum / Math.max(1, baselineSlice.length)).toFixed(1));

    // Recent 7-Day Average: Last 7 recorded days
    const recent7Slice = sorted.slice(-Math.min(7, sorted.length));
    const recent7Sum = recent7Slice.reduce((sum, s) => sum + s.overallScore, 0);
    const recent7DayAvg = Number((recent7Sum / Math.max(1, recent7Slice.length)).toFixed(1));

    // Percentage change = ((Recent - Baseline) / Baseline) * 100
    const rawDiff = recent7DayAvg - baseline14DayAvg;
    const percentageChange = Number(((rawDiff / (baseline14DayAvg || 1)) * 100).toFixed(1));

    // Threshold check: Drop by more than 15% (e.g. -15.1% or lower)
    const isDeclineTriggered = percentageChange < -15.0;

    let status: 'green' | 'amber' | 'red' = 'green';
    if (isDeclineTriggered) {
      status = 'red';
    } else if (percentageChange < -5.0 || recent7DayAvg < 68) {
      status = 'amber';
    }

    // Latest domain breakdown
    const latest = sorted[sorted.length - 1];
    const latestDomains = latest ? latest.domainScores : { memory: 70, attention: 70, orientation: 70, language: 70 };

    // Formulate clinical insights
    const insights: string[] = [];
    if (isDeclineTriggered) {
      insights.push(`Significant 7-day cognitive decline detected (${percentageChange}% vs 14-day baseline).`);
      insights.push(`Notable deficit in Memory (${latestDomains.memory}/100) and Attention (${latestDomains.attention}/100).`);
      insights.push(`Immediate caregiver notification dispatched to ${patient.caregiver.name}.`);
    } else if (status === 'amber') {
      insights.push(`Mild cognitive fluctuations observed (${percentageChange}% change). Orientation remains resilient.`);
      insights.push('Recommend continuous monitoring and maintaining familiar daily routine.');
    } else {
      insights.push(`Cognitive baseline stable at ${recent7DayAvg}/100 (+${Math.max(0, percentageChange)}%).`);
      insights.push('Excellent cognitive maintenance and high positive engagement with regional games.');
    }

    return {
      dailyScore: latest ? latest.overallScore : patient.currentScore,
      domainScores: latestDomains,
      baseline14DayAvg,
      recent7DayAvg,
      percentageChange,
      isDeclineTriggered,
      status,
      suggestedLevel: recent7DayAvg > 80 ? 3 : recent7DayAvg > 65 ? 2 : 1,
      insights,
    };
  }

  /**
   * Generates or updates decline alert if not already logged
   */
  public static verifyAndTriggerAlert(patient: PatientProfile): DeclineAlert | null {
    const analysis = this.analyzePatient(patient);
    if (!analysis.isDeclineTriggered) return null;

    const existingAlerts = StorageService.getAlerts();
    const todayStr = new Date().toISOString().split('T')[0];
    const existing = existingAlerts.find(
      (a) => a.patientId === patient.id && a.date === todayStr && a.severity === 'red'
    );

    if (existing) return existing;

    const newAlert: DeclineAlert = {
      id: `alt-${patient.id}-${Date.now()}`,
      patientId: patient.id,
      patientName: `${patient.name} (${patient.nickname})`,
      date: todayStr,
      severity: 'red',
      title: '7-Day Cognitive Decline Exceeds 15% Threshold',
      description: `${patient.nickname}'s rolling 7-day average score (${analysis.recent7DayAvg}) dropped ${Math.abs(
        analysis.percentageChange
      )}% below the 14-day baseline (${analysis.baseline14DayAvg}).`,
      baselineAvg: analysis.baseline14DayAvg,
      recentAvg: analysis.recent7DayAvg,
      percentageDrop: analysis.percentageChange,
      affectedDomains: ['Visual Memory Recall', 'Pattern Sequence Following'],
      recommendedAction: 'Caregiver review recommended. Confirm medication consistency, ensure restful sleep, and consult primary physician.',
      acknowledged: false,
    };

    return newAlert;
  }
}
