import { jsPDF } from 'jspdf';
import { PatientProfile } from '../types';
import { CognitiveEngine } from './cognitiveEngine';
import { StorageService } from './storage';

export class ReportGenerator {
  public static generatePatientPDF(patient: PatientProfile): void {
    const analysis = CognitiveEngine.analyzePatient(patient);
    const scores = StorageService.getPatientScores(patient.id);
    const alerts = StorageService.getAlerts().filter((a) => a.patientId === patient.id);

    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    let y = 18;

    // Header banner
    doc.setFillColor(13, 92, 117); // #0D5C75 Teal
    doc.rect(0, 0, pageWidth, 28, 'F');

    doc.setTextColor(255, 255, 255);
    doc.setFontSize(18);
    doc.setFont('helvetica', 'bold');
    doc.text('MindMate - Cognitive Health Assessment', 14, 12);

    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.text('AI Cognitive Gaming & Decline Monitoring Platform | Team Algo-X (SIH26003)', 14, 18);
    doc.text(`Generated: ${new Date().toLocaleDateString('en-IN', { dateStyle: 'full' })}`, 14, 23);

    y = 36;

    // Patient Information Block
    doc.setTextColor(20, 30, 45);
    doc.setFontSize(13);
    doc.setFont('helvetica', 'bold');
    doc.text('1. PATIENT CLINICAL PROFILE', 14, y);
    y += 4;

    doc.setDrawColor(203, 213, 225);
    doc.line(14, y, pageWidth - 14, y);
    y += 6;

    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');

    // 2-column key info
    const col1X = 16;
    const col2X = 105;

    doc.text(`Full Name: ${patient.name} (${patient.nickname})`, col1X, y);
    doc.text(`Diagnosis: ${patient.diagnosis}`, col2X, y);
    y += 5;

    doc.text(`Age / Gender: ${patient.age} years / ${patient.gender}`, col1X, y);
    doc.text(`Region / State: ${patient.location}, ${patient.state}`, col2X, y);
    y += 5;

    doc.text(`Primary Language: ${patient.language.toUpperCase()}`, col1X, y);
    doc.text(`Caregiver: ${patient.caregiver.name} (${patient.caregiver.relation}) - ${patient.caregiver.phone}`, col2X, y);
    y += 5;

    doc.text(`Emergency Contact: ${patient.emergencyContacts[0]?.name || 'N/A'}`, col1X, y);
    doc.text(`Consent on File: ${patient.consentGiven ? 'YES (Verified by Caregiver)' : 'PENDING'}`, col2X, y);
    y += 9;

    // Cognitive Health Score Summary
    doc.setFontSize(13);
    doc.setFont('helvetica', 'bold');
    doc.text('2. COGNITIVE ANALYSIS & 14-DAY BASELINE COMPARISON', 14, y);
    y += 4;
    doc.line(14, y, pageWidth - 14, y);
    y += 7;

    // Score KPI cards
    const cardWidth = 56;
    const cardHeight = 22;

    // Card 1: 14-Day Baseline
    doc.setFillColor(241, 245, 249);
    doc.roundedRect(14, y, cardWidth, cardHeight, 2, 2, 'F');
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text('14-DAY BASELINE', 18, y + 6);
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(13, 92, 117);
    doc.text(`${analysis.baseline14DayAvg} / 100`, 18, y + 15);

    // Card 2: Recent 7-Day Average
    doc.setFillColor(241, 245, 249);
    doc.roundedRect(76, y, cardWidth, cardHeight, 2, 2, 'F');
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text('RECENT 7-DAY AVERAGE', 80, y + 6);
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(analysis.isDeclineTriggered ? 220 : 30, analysis.isDeclineTriggered ? 38 : 130, 38);
    doc.text(`${analysis.recent7DayAvg} / 100`, 80, y + 15);

    // Card 3: Percentage Change
    doc.setFillColor(analysis.isDeclineTriggered ? 254 : 240, analysis.isDeclineTriggered ? 242 : 253, analysis.isDeclineTriggered ? 242 : 244);
    doc.roundedRect(138, y, cardWidth, cardHeight, 2, 2, 'F');
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text('7-DAY SCORE VARIATION', 142, y + 6);
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(analysis.percentageChange < -15 ? 220 : analysis.percentageChange < 0 ? 217 : 22, analysis.percentageChange < -15 ? 38 : analysis.percentageChange < 0 ? 119 : 101, 38);
    doc.text(`${analysis.percentageChange > 0 ? '+' : ''}${analysis.percentageChange}%`, 142, y + 15);

    y += cardHeight + 8;

    // Cognitive Domain Breakdown
    doc.setTextColor(20, 30, 45);
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('Cognitive Domain Performance (Latest):', 14, y);
    y += 5;

    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    const d = analysis.domainScores;
    doc.text(`• Memory (Visual & Spatial Recall - Weight 35%): ${d.memory}/100`, 18, y); y += 4.5;
    doc.text(`• Attention & Sequence Processing (Weight 25%): ${d.attention}/100`, 18, y); y += 4.5;
    doc.text(`• Orientation to Time, Place & People (Weight 20%): ${d.orientation}/100`, 18, y); y += 4.5;
    doc.text(`• Language & Picture Naming (Weight 20%): ${d.language}/100`, 18, y); y += 7;

    // Decline Alerts Section
    doc.setFontSize(13);
    doc.setFont('helvetica', 'bold');
    doc.text('3. CLINICAL ALERTS & DECLINE FLAGS', 14, y);
    y += 4;
    doc.line(14, y, pageWidth - 14, y);
    y += 6;

    if (alerts.length > 0) {
      alerts.forEach((alert) => {
        const isRed = alert.severity === 'red';
        doc.setFillColor(isRed ? 254 : 254, isRed ? 242 : 249, isRed ? 242 : 231);
        doc.roundedRect(14, y, pageWidth - 28, 20, 2, 2, 'F');
        doc.setDrawColor(isRed ? 239 : 245, isRed ? 68 : 158, isRed ? 68 : 11);
        doc.rect(14, y, pageWidth - 28, 20, 'S');

        doc.setFontSize(9);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(isRed ? 185 : 180, isRed ? 28 : 83, 28);
        doc.text(`[${alert.severity.toUpperCase()}] ${alert.title} (${alert.date})`, 18, y + 6);

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        doc.setTextColor(51, 65, 85);
        const splitDesc = doc.splitTextToSize(alert.description, pageWidth - 36);
        doc.text(splitDesc, 18, y + 11);

        y += 24;
      });
    } else {
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(71, 85, 105);
      doc.text('No critical decline alerts recorded in past 30 days.', 18, y);
      y += 8;
    }

    // Recommendations
    y += 3;
    doc.setTextColor(20, 30, 45);
    doc.setFontSize(13);
    doc.setFont('helvetica', 'bold');
    doc.text('4. CLINICAL & CAREGIVER RECOMMENDATIONS', 14, y);
    y += 4;
    doc.line(14, y, pageWidth - 14, y);
    y += 6;

    doc.setFontSize(8.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(51, 65, 85);

    if (analysis.isDeclineTriggered) {
      doc.text('1. Consult Geriatrician / Neurologist: Schedule formal MMSE / MoCA evaluation.', 18, y); y += 4.5;
      doc.text('2. Rule out Reversible Factors: Check for urinary tract infection, sleep disruptions, or vitamin deficiencies.', 18, y); y += 4.5;
      doc.text('3. Daily Routine Adherence: Ensure family reinforces familiar cues (Gamusa, Bihu music, photo album).', 18, y); y += 4.5;
      doc.text('4. ASHA Support: Request home visit verification from local ASHA worker.', 18, y); y += 4.5;
    } else {
      doc.text('1. Continue Daily Cognitive Workouts: Maintain daily 15-minute sessions on MindMate.', 18, y); y += 4.5;
      doc.text('2. Positive Reminiscence: Encourage regular browsing of Family Photo Album with audio notes.', 18, y); y += 4.5;
      doc.text('3. Social & Physical Engagement: Support gentle morning garden walks and hydration.', 18, y); y += 4.5;
    }

    // Historical 7-day Score Table
    y += 4;
    doc.setTextColor(20, 30, 45);
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('5. RECENT 7-DAY SCORE RECORD', 14, y);
    y += 4;

    const recentScores = scores.slice(-7);
    doc.setFillColor(241, 245, 249);
    doc.rect(14, y, pageWidth - 28, 6, 'F');
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text('Date', 18, y + 4);
    doc.text('Overall Score', 55, y + 4);
    doc.text('Memory', 95, y + 4);
    doc.text('Attention', 130, y + 4);
    doc.text('Orientation', 165, y + 4);
    y += 6;

    doc.setFont('helvetica', 'normal');
    recentScores.forEach((s) => {
      doc.text(s.date, 18, y + 4);
      doc.text(`${s.overallScore} / 100`, 55, y + 4);
      doc.text(`${s.domainScores.memory}`, 95, y + 4);
      doc.text(`${s.domainScores.attention}`, 130, y + 4);
      doc.text(`${s.domainScores.orientation}`, 165, y + 4);
      y += 5;
    });

    // Footer
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text('MindMate Assessment Report | Confidential Healthcare Record | Verified for North East India Rural Telecare', 14, 288);

    doc.save(`MindMate_Report_${patient.name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`);
  }
}
