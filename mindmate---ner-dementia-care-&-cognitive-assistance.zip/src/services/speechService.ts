/**
 * Speech Recognition and Text-to-Speech (TTS) Service using Web Speech API
 */

import { LanguageCode } from '../types';

interface VoiceRecognitionOptions {
  onResult: (phrase: string) => void;
  onError?: (err: unknown) => void;
  onEnd?: () => void;
}

// Map app language code to BCP 47 speech synthesis/recognition tags
const LANG_MAP: Record<LanguageCode, string> = {
  en: 'en-IN',
  hi: 'hi-IN',
  as: 'as-IN',
  bn: 'bn-IN',
  te: 'te-IN',
  ta: 'ta-IN',
  mr: 'mr-IN',
  gu: 'gu-IN',
  kn: 'kn-IN',
  ml: 'ml-IN',
  pa: 'pa-IN',
  or: 'or-IN',
  ur: 'ur-IN',
  mni: 'mni-IN',
  lus: 'en-IN', // Fallback for Mizo
  brx: 'as-IN', // Fallback for Bodo
  mai: 'hi-IN', // Maithili
  sa: 'hi-IN', // Sanskrit
  ks: 'ur-IN', // Kashmiri
  ne: 'ne-NP', // Nepali
  gom: 'mr-IN', // Konkani
  sd: 'hi-IN', // Sindhi
  doi: 'hi-IN', // Dogri
  sat: 'bn-IN', // Santali
  kha: 'en-IN', // Khasi
  grt: 'en-IN', // Garo
};

class SpeechService {
  private isTtsSupported: boolean = false;
  private isRecognitionSupported: boolean = false;
  private recognition: any = null;
  private activeListening = false;

  constructor() {
    if (typeof window !== 'undefined') {
      this.isTtsSupported = 'speechSynthesis' in window;
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      this.isRecognitionSupported = !!SpeechRecognition;
    }
  }

  public speak(text: string, lang: LanguageCode = 'en'): Promise<void> {
    return new Promise((resolve) => {
      if (!this.isTtsSupported) {
        resolve();
        return;
      }

      window.speechSynthesis.cancel(); // Stop any pending utterance
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = LANG_MAP[lang] || 'en-IN';
      utterance.rate = 0.88; // Gentle, slightly slower cadence for dementia patients
      utterance.pitch = 1.05;

      utterance.onend = () => resolve();
      utterance.onerror = () => resolve();

      window.speechSynthesis.speak(utterance);
    });
  }

  public stopSpeaking(): void {
    if (this.isTtsSupported) {
      window.speechSynthesis.cancel();
    }
  }

  public startListening(
    lang: LanguageCode,
    options: VoiceRecognitionOptions
  ): boolean {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      return false;
    }

    try {
      if (this.recognition) {
        this.recognition.abort();
      }

      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = LANG_MAP[lang] || 'en-IN';

      recognition.onstart = () => {
        this.activeListening = true;
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript.toLowerCase().trim();
        options.onResult(transcript);
      };

      recognition.onerror = (event: any) => {
        this.activeListening = false;
        if (options.onError) options.onError(event);
      };

      recognition.onend = () => {
        this.activeListening = false;
        if (options.onEnd) options.onEnd();
      };

      this.recognition = recognition;
      recognition.start();
      return true;
    } catch (e) {
      this.activeListening = false;
      if (options.onError) options.onError(e);
      return false;
    }
  }

  public stopListening(): void {
    if (this.recognition && this.activeListening) {
      this.recognition.stop();
      this.activeListening = false;
    }
  }

  public isVoiceSupported(): boolean {
    return this.isRecognitionSupported;
  }
}

export const speechService = new SpeechService();
