import { PatientProfile, DailyCognitiveScore, DeclineAlert, AshaVisitNote, GameSessionResult } from '../types';

const STORAGE_KEYS = {
  PATIENTS: 'mindmate_patients_v1',
  SCORES_PREFIX: 'mindmate_scores_',
  SESSIONS_PREFIX: 'mindmate_sessions_',
  ALERTS: 'mindmate_alerts_v1',
  ASHA_NOTES: 'mindmate_asha_notes_v1',
  ACTIVE_PATIENT: 'mindmate_active_patient_id',
  CURRENT_ROLE: 'mindmate_current_role',
  SYNC_TIMESTAMP: 'mindmate_last_sync_time',
};

// Seed 3 realistic North Eastern India patients
const SEED_PATIENTS: PatientProfile[] = [
  {
    id: 'p1',
    name: 'Nirmala Baruah',
    nickname: 'Aita',
    age: 74,
    gender: 'Female',
    location: 'Tezpur, Sonitpur',
    district: 'Sonitpur',
    state: 'Assam',
    language: 'as',
    diagnosis: 'Mild Cognitive Impairment',
    status: 'red',
    statusReason: '7-day score dropped by 20.5% (below 15% threshold). Memory recall and orientation attention reduced.',
    baselineScore: 79.5,
    currentScore: 63.2,
    scoreChangePct: -20.5,
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300&auto=format&fit=crop&q=80',
    caregiver: {
      name: 'Pranjal Baruah',
      relation: 'Son',
      phone: '+91 94350 12849',
      email: 'pranjal.baruah@assamcare.in',
    },
    emergencyContacts: [
      { name: 'Pranjal Baruah (Son)', relation: 'Son', phone: '+91 94350 12849' },
      { name: 'Dr. Bhupen Barman (Tezpur Medical College)', relation: 'Physician', phone: '+91 98640 44221' },
      { name: 'Rani Roy (Local ASHA Worker)', relation: 'Community Health Worker', phone: '+91 97060 88192' },
    ],
    consentGiven: true,
    lastScreeningDate: '2026-09-21',
    dailyRoutine: [
      {
        id: 'r1',
        time: '07:30 AM',
        title: 'Morning Assam Tea & BP Medicine',
        description: 'Warm cup of Lal Cha with Telmisartan 40mg pill box',
        category: 'medicine',
        completed: true,
        iconName: 'Coffee',
      },
      {
        id: 'r2',
        time: '08:30 AM',
        title: 'Gentle Walk in Garden',
        description: '15-minute relaxing stroll among the marigolds and nahor trees',
        category: 'activity',
        completed: true,
        iconName: 'Footprints',
      },
      {
        id: 'r3',
        time: '12:30 PM',
        title: 'Afternoon Fish Curry & Memory Vitamin',
        description: 'Nutritious Joha rice, Maasor Tenga and Omega-3 supplement',
        category: 'meal',
        completed: false,
        iconName: 'Utensils',
      },
      {
        id: 'r4',
        time: '04:00 PM',
        title: 'MindMate Memory Card Match',
        description: 'Daily cognitive workout with Assamese regional symbols',
        category: 'activity',
        completed: false,
        iconName: 'Gamepad2',
      },
      {
        id: 'r5',
        time: '06:30 PM',
        title: 'Evening Phone Call with Sneha',
        description: 'Granddaughter Sneha calls from Guwahati college hostel',
        category: 'activity',
        completed: false,
        iconName: 'PhoneCall',
      },
    ],
    familyMembers: [
      {
        id: 'f1',
        name: 'Pranjal Baruah',
        relation: 'Son (বৰ ল’ৰা)',
        location: 'Tezpur, living next door',
        phone: '+91 94350 12849',
        photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
        voiceNote: 'This is your elder son Pranjal. He brings your fresh vegetables every morning.',
        keyMemory: 'He always brings fresh morning milk and checks your BP.',
      },
      {
        id: 'f2',
        name: 'Sneha Baruah',
        relation: 'Granddaughter (নাতিনী)',
        location: 'Guwahati University',
        phone: '+91 94351 99201',
        photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
        voiceNote: 'This is Sneha, your beloved granddaughter. She is studying engineering.',
        keyMemory: 'You taught her how to weave the red phool on the Gamusa.',
      },
      {
        id: 'f3',
        name: 'Minoti Hazarika',
        relation: 'Sister (ভনীয়েক)',
        location: 'Nagaon, Assam',
        phone: '+91 94352 11983',
        photoUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300&auto=format&fit=crop&q=80',
        voiceNote: 'This is your younger sister Minoti. She loves singing Bihu naam with you.',
        keyMemory: 'Every Rongali Bihu, she brings Pitha and Laru for you.',
      },
    ],
    ashaNotes: [
      'Sep 21: Patient showed mild confusion recalling today\'s weekday. Responds very warmly to Bihu dhol music.',
      'Sep 14: Completed full orientation with ASHA Rani Roy. Blood pressure 128/82 mmHg.',
    ],
  },
  {
    id: 'p2',
    name: 'Lalhmangaiha',
    nickname: 'Pu Zara',
    age: 78,
    gender: 'Male',
    location: 'Mission Veng, Aizawl',
    district: 'Aizawl',
    state: 'Mizoram',
    language: 'lus',
    diagnosis: 'Early Alzheimer\'s',
    status: 'green',
    statusReason: 'Cognitive score stable across 30 days (+0.8% change). High engagement in folk melody recall.',
    baselineScore: 74.2,
    currentScore: 74.8,
    scoreChangePct: 0.8,
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80',
    caregiver: {
      name: 'Lalrinsangi',
      relation: 'Daughter',
      phone: '+91 98623 55902',
      email: 'rinsangi.zara@mizoramcare.in',
    },
    emergencyContacts: [
      { name: 'Lalrinsangi (Daughter)', relation: 'Daughter', phone: '+91 98623 55902' },
      { name: 'Civil Hospital Aizawl', relation: 'Hospital', phone: '+91 0389 2322318' },
    ],
    consentGiven: true,
    lastScreeningDate: '2026-09-22',
    dailyRoutine: [
      {
        id: 'r21',
        time: '07:00 AM',
        title: 'Morning Prayer & Red Tea',
        description: 'Quiet devotional time and warm ginger tea on the veranda',
        category: 'activity',
        completed: true,
        iconName: 'Coffee',
      },
      {
        id: 'r22',
        time: '08:15 AM',
        title: 'Morning Memory & Heart Medication',
        description: 'Donepezil 5mg and Aspirin 75mg with breakfast',
        category: 'medicine',
        completed: true,
        iconName: 'Pill',
      },
      {
        id: 'r23',
        time: '03:30 PM',
        title: 'MindMate Folk Music & Rhythm Game',
        description: 'Mizo traditional drum and folk song recall session',
        category: 'activity',
        completed: false,
        iconName: 'Music',
      },
    ],
    familyMembers: [
      {
        id: 'f21',
        name: 'Lalrinsangi',
        relation: 'Daughter (Fanu)',
        location: 'Aizawl, living together',
        phone: '+91 98623 55902',
        photoUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&auto=format&fit=crop&q=80',
        voiceNote: 'This is your daughter Lalrinsangi. She prepares your favorite pumpkin leaves stew.',
        keyMemory: 'She takes you to church every Sunday morning.',
      },
    ],
    ashaNotes: ['Sep 22: Highly stable mood. Enjoys Mizo folk hymn songs.'],
  },
  {
    id: 'p3',
    name: 'Bimola Devi',
    nickname: 'Ima Bimola',
    age: 71,
    gender: 'Female',
    location: 'Uripok, Imphal West',
    district: 'Imphal West',
    state: 'Manipur',
    language: 'mni',
    diagnosis: 'Vascular Dementia',
    status: 'amber',
    statusReason: 'Fluctuations in attention and sequence processing over past 10 days (-7.4%). Monitor closely.',
    baselineScore: 69.0,
    currentScore: 63.9,
    scoreChangePct: -7.4,
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300&auto=format&fit=crop&q=80',
    caregiver: {
      name: 'Sanatomba Singh',
      relation: 'Nephew',
      phone: '+91 98625 11840',
      email: 'sanatomba.singh@manipurmail.com',
    },
    emergencyContacts: [
      { name: 'Sanatomba Singh (Nephew)', relation: 'Nephew', phone: '+91 98625 11840' },
      { name: 'RIMS Imphal Emergency', relation: 'Hospital', phone: '+91 0385 2414629' },
    ],
    consentGiven: true,
    lastScreeningDate: '2026-09-20',
    dailyRoutine: [
      {
        id: 'r31',
        time: '08:00 AM',
        title: 'Morning Medicine & Kanghou',
        description: 'Blood pressure medication with boiled peas',
        category: 'medicine',
        completed: true,
        iconName: 'Pill',
      },
      {
        id: 'r32',
        time: '11:00 AM',
        title: 'MindMate Picture Recognition',
        description: 'Loktak lake, Sangai deer and handloom picture game',
        category: 'activity',
        completed: false,
        iconName: 'Gamepad2',
      },
    ],
    familyMembers: [
      {
        id: 'f31',
        name: 'Sanatomba Singh',
        relation: 'Nephew (মমাঙ ইবুঙো)',
        location: 'Imphal',
        phone: '+91 98625 11840',
        photoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&auto=format&fit=crop&q=80',
        voiceNote: 'This is Sanatomba, your nephew who visits every afternoon.',
        keyMemory: 'He brings fresh lotus stems from Loktak Lake.',
      },
    ],
    ashaNotes: ['Sep 20: Blood pressure slightly elevated at 138/88. Recommended daily hydration.'],
  },
];

// Helper to generate 30 days of data ending at today
function generate30DaysScores(patientId: string): DailyCognitiveScore[] {
  const scores: DailyCognitiveScore[] = [];
  const today = new Date();

  for (let i = 29; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];

    if (patientId === 'p1') {
      // Nirmala Baruah: Days 0..16 high (78-83), Days 17..29 decline down to 60-64!
      // This produces 14-day baseline of ~80, and 7-day recent average of ~63 (-21% drop)
      let overall: number;
      let memory: number;
      let attention: number;
      let orientation: number;
      let language: number;

      if (i >= 14) {
        // Earlier days: High healthy baseline
        const noise = ((i * 7) % 5) - 2;
        overall = 79 + noise;
        memory = 81 + noise;
        attention = 78 + noise;
        orientation = 82 + noise;
        language = 80 + noise;
      } else if (i >= 7) {
        // Transition days
        const progress = (14 - i) / 7;
        overall = Math.round(79 - progress * 10);
        memory = Math.round(81 - progress * 16);
        attention = Math.round(78 - progress * 12);
        orientation = Math.round(82 - progress * 8);
        language = Math.round(80 - progress * 6);
      } else {
        // Recent 7 days: Significant decline!
        const noise = ((i * 3) % 4) - 2;
        overall = 63 + noise;
        memory = 54 + noise;
        attention = 62 + noise;
        orientation = 72 + noise;
        language = 74 + noise;
      }

      scores.push({
        date: dateStr,
        overallScore: Math.max(30, Math.min(100, overall)),
        domainScores: {
          memory: Math.max(25, Math.min(100, memory)),
          attention: Math.max(30, Math.min(100, attention)),
          orientation: Math.max(40, Math.min(100, orientation)),
          language: Math.max(45, Math.min(100, language)),
        },
        gamesPlayed: ['memory_match', 'sequence_recall', 'orientation_quiz'],
        averageReactionTimeMs: i < 7 ? 2850 : 1720,
      });
    } else if (patientId === 'p2') {
      // Pu Zara: Stable green
      const noise = ((i * 11) % 5) - 2;
      scores.push({
        date: dateStr,
        overallScore: 74 + noise,
        domainScores: {
          memory: 73 + noise,
          attention: 75 + noise,
          orientation: 76 + noise,
          language: 74 + noise,
        },
        gamesPlayed: ['folk_music', 'memory_match'],
        averageReactionTimeMs: 1800 + noise * 40,
      });
    } else {
      // Bimola Devi: Fluctuating amber
      const wave = Math.sin(i * 0.8) * 4;
      const score = Math.round(66 + wave);
      scores.push({
        date: dateStr,
        overallScore: score,
        domainScores: {
          memory: score - 2,
          attention: score - 4,
          orientation: score + 3,
          language: score + 1,
        },
        gamesPlayed: ['name_object', 'sequence_recall'],
        averageReactionTimeMs: 2100,
      });
    }
  }

  return scores;
}

const SEED_ALERTS: DeclineAlert[] = [
  {
    id: 'alt-p1-01',
    patientId: 'p1',
    patientName: 'Nirmala Baruah (Aita)',
    date: new Date().toISOString().split('T')[0],
    severity: 'red',
    title: 'Significant Cognitive Decline Alert (>15% Drop)',
    description: 'Aita\'s 7-day average cognitive score (63.2) is 20.5% lower than her established 14-day baseline (79.5). Marked reduction in visual memory card recall and sequence tracking.',
    baselineAvg: 79.5,
    recentAvg: 63.2,
    percentageDrop: -20.5,
    affectedDomains: ['Memory Recall (-27%)', 'Attention & Sequence (-18%)'],
    recommendedAction: 'Schedule clinical evaluation with Dr. Bhupen Barman (Tezpur). Review hydration, sleep patterns, and daily Donepezil/BP adherence.',
    acknowledged: false,
  },
  {
    id: 'alt-p3-01',
    patientId: 'p3',
    patientName: 'Bimola Devi',
    date: new Date(Date.now() - 86400000 * 2).toISOString().split('T')[0],
    severity: 'amber',
    title: 'Attention & Sequence Fluctuation',
    description: 'Recent scores exhibit mild dip (-7.4%) during afternoon sessions. Orientation remains intact.',
    baselineAvg: 69.0,
    recentAvg: 63.9,
    percentageDrop: -7.4,
    affectedDomains: ['Attention (-11%)'],
    recommendedAction: 'Caregiver Sanatomba to supervise morning puzzle sessions and check blood pressure.',
    acknowledged: true,
  },
];

const SEED_ASHA_NOTES: AshaVisitNote[] = [
  {
    id: 'note-01',
    patientId: 'p1',
    patientName: 'Nirmala Baruah',
    date: new Date().toISOString().split('T')[0],
    ashaName: 'Rani Roy (ASHA)',
    mood: 'Calm',
    medicationAdherence: 'Taken',
    observation: 'Visited home in Tezpur. Patient smiled when hearing Assamese Bihu tunes. Reminded son Pranjal about clinical review.',
    synced: true,
  },
  {
    id: 'note-02',
    patientId: 'p2',
    patientName: 'Lalhmangaiha',
    date: new Date(Date.now() - 86400000).toISOString().split('T')[0],
    ashaName: 'Lalthanzuali (ASHA Aizawl)',
    mood: 'Cheerful',
    medicationAdherence: 'Taken',
    observation: 'Pu Zara actively sang church hymns during visit. Family highly supportive.',
    synced: true,
  },
];

export class StorageService {
  private static initPromise: Promise<void> | null = null;

  public static async init(): Promise<void> {
    if (!this.initPromise) {
      this.initPromise = (async () => {
        if (typeof window === 'undefined') return;

        // Initialize patients if not present
        if (!localStorage.getItem(STORAGE_KEYS.PATIENTS)) {
          localStorage.setItem(STORAGE_KEYS.PATIENTS, JSON.stringify(SEED_PATIENTS));
          localStorage.setItem(STORAGE_KEYS.ACTIVE_PATIENT, 'p1');
          localStorage.setItem(STORAGE_KEYS.CURRENT_ROLE, 'patient');

          // Seed scores for all patients
          SEED_PATIENTS.forEach((p) => {
            const scores = generate30DaysScores(p.id);
            localStorage.setItem(STORAGE_KEYS.SCORES_PREFIX + p.id, JSON.stringify(scores));
          });

          // Seed alerts and notes
          localStorage.setItem(STORAGE_KEYS.ALERTS, JSON.stringify(SEED_ALERTS));
          localStorage.setItem(STORAGE_KEYS.ASHA_NOTES, JSON.stringify(SEED_ASHA_NOTES));
          localStorage.setItem(STORAGE_KEYS.SYNC_TIMESTAMP, new Date().toISOString());
        }
      })();
    }
    return this.initPromise;
  }

  // Patients
  public static getPatients(): PatientProfile[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PATIENTS);
      return data ? JSON.parse(data) : SEED_PATIENTS;
    } catch {
      return SEED_PATIENTS;
    }
  }

  public static getPatientById(id: string): PatientProfile | null {
    const patients = this.getPatients();
    return patients.find((p) => p.id === id) || patients[0] || null;
  }

  public static updatePatient(updated: PatientProfile): void {
    const patients = this.getPatients().map((p) => (p.id === updated.id ? updated : p));
    localStorage.setItem(STORAGE_KEYS.PATIENTS, JSON.stringify(patients));
  }

  // Active Patient & Role
  public static getActivePatientId(): string {
    return localStorage.getItem(STORAGE_KEYS.ACTIVE_PATIENT) || 'p1';
  }

  public static setActivePatientId(id: string): void {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_PATIENT, id);
  }

  // Daily Cognitive Scores
  public static getPatientScores(patientId: string): DailyCognitiveScore[] {
    try {
      const key = STORAGE_KEYS.SCORES_PREFIX + patientId;
      const data = localStorage.getItem(key);
      if (data) return JSON.parse(data);
      const generated = generate30DaysScores(patientId);
      localStorage.setItem(key, JSON.stringify(generated));
      return generated;
    } catch {
      return generate30DaysScores(patientId);
    }
  }

  public static addGameSession(result: GameSessionResult): void {
    try {
      const key = STORAGE_KEYS.SESSIONS_PREFIX + result.patientId;
      const existing = localStorage.getItem(key);
      const sessions: GameSessionResult[] = existing ? JSON.parse(existing) : [];
      sessions.push(result);
      localStorage.setItem(key, JSON.stringify(sessions));

      // Also update today's daily cognitive score
      const scores = this.getPatientScores(result.patientId);
      const todayStr = new Date().toISOString().split('T')[0];
      const todayIndex = scores.findIndex((s) => s.date === todayStr);

      if (todayIndex >= 0) {
        // Weighted blend with new session score
        const current = scores[todayIndex];
        const newOverall = Math.round(current.overallScore * 0.7 + result.score * 0.3);
        current.overallScore = Math.min(100, Math.max(20, newOverall));
        if (!current.gamesPlayed.includes(result.gameType)) {
          current.gamesPlayed.push(result.gameType);
        }
        scores[todayIndex] = current;
      } else {
        scores.push({
          date: todayStr,
          overallScore: result.score,
          domainScores: {
            memory: result.score,
            attention: result.score,
            orientation: 75,
            language: 75,
          },
          gamesPlayed: [result.gameType],
          averageReactionTimeMs: result.reactionTimeMs,
        });
      }
      localStorage.setItem(STORAGE_KEYS.SCORES_PREFIX + result.patientId, JSON.stringify(scores));
    } catch (e) {
      console.warn('Failed to save game session', e);
    }
  }

  // Decline Alerts
  public static getAlerts(): DeclineAlert[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ALERTS);
      return data ? JSON.parse(data) : SEED_ALERTS;
    } catch {
      return SEED_ALERTS;
    }
  }

  public static acknowledgeAlert(alertId: string): void {
    const alerts = this.getAlerts().map((a) => (a.id === alertId ? { ...a, acknowledged: true } : a));
    localStorage.setItem(STORAGE_KEYS.ALERTS, JSON.stringify(alerts));
  }

  // ASHA Visit Notes
  public static getAshaNotes(): AshaVisitNote[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ASHA_NOTES);
      return data ? JSON.parse(data) : SEED_ASHA_NOTES;
    } catch {
      return SEED_ASHA_NOTES;
    }
  }

  public static addAshaNote(note: Omit<AshaVisitNote, 'id' | 'synced'>): AshaVisitNote {
    const notes = this.getAshaNotes();
    const newNote: AshaVisitNote = {
      ...note,
      id: 'note-' + Date.now(),
      synced: false,
    };
    notes.unshift(newNote);
    localStorage.setItem(STORAGE_KEYS.ASHA_NOTES, JSON.stringify(notes));
    return newNote;
  }

  public static syncAshaRecords(): { count: number; timestamp: string } {
    const notes = this.getAshaNotes().map((n) => ({ ...n, synced: true }));
    localStorage.setItem(STORAGE_KEYS.ASHA_NOTES, JSON.stringify(notes));
    const now = new Date().toISOString();
    localStorage.setItem(STORAGE_KEYS.SYNC_TIMESTAMP, now);
    return { count: notes.length, timestamp: now };
  }

  public static getLastSyncTime(): string {
    return localStorage.getItem(STORAGE_KEYS.SYNC_TIMESTAMP) || new Date().toISOString();
  }
}
