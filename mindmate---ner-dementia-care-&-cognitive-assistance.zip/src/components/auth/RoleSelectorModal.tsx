import React from 'react';
import { Users, HeartHandshake, UserCheck, X, ArrowRight, ShieldCheck } from 'lucide-react';
import { Role } from '../../types';

interface RoleSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentRole: Role;
  onSelectRole: (role: Role) => void;
}

export const RoleSelectorModal: React.FC<RoleSelectorModalProps> = ({
  isOpen,
  onClose,
  currentRole,
  onSelectRole,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 p-4 backdrop-blur-xs animate-fadeIn">
      <div className="relative w-full max-w-xl rounded-3xl bg-white p-6 sm:p-8 shadow-2xl border-2 border-teal-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:bg-slate-100 transition"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="flex items-center gap-2 mb-1">
          <ShieldCheck className="w-5 h-5 text-teal-700" />
          <span className="text-xs font-bold uppercase tracking-wider text-teal-800">
            Smart India Hackathon 2026 | Team Algo-X (SIH26003)
          </span>
        </div>

        <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
          Switch MindMate Demo Role
        </h2>
        <p className="text-sm text-slate-600 font-medium mt-1 mb-6">
          Choose a pre-seeded demo profile to experience MindMate from that perspective.
        </p>

        <div className="space-y-4">
          {/* Demo 1: Patient */}
          <button
            onClick={() => {
              onSelectRole('patient');
              onClose();
            }}
            className={`w-full p-5 rounded-2xl border-3 text-left transition flex items-center justify-between gap-4 active:scale-98 ${
              currentRole === 'patient'
                ? 'bg-amber-50 border-amber-400 ring-2 ring-amber-300'
                : 'bg-white border-slate-200 hover:border-teal-400 hover:bg-teal-50/40'
            }`}
          >
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-black text-2xl shadow-sm shrink-0">
                👵
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-black text-slate-900">1. Elder Patient Mode</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-100 text-teal-800">
                    Voice-First
                  </span>
                </div>
                <p className="text-xs font-semibold text-slate-600 mt-0.5">
                  Aita Nirmala Baruah (74, Tezpur). Huge buttons, minimal text, Web Speech voice navigation, 5 regional games.
                </p>
              </div>
            </div>
            <ArrowRight className="w-5 h-5 text-slate-400 shrink-0" />
          </button>

          {/* Demo 2: Caregiver */}
          <button
            onClick={() => {
              onSelectRole('caregiver');
              onClose();
            }}
            className={`w-full p-5 rounded-2xl border-3 text-left transition flex items-center justify-between gap-4 active:scale-98 ${
              currentRole === 'caregiver'
                ? 'bg-teal-50 border-teal-500 ring-2 ring-teal-300'
                : 'bg-white border-slate-200 hover:border-teal-400 hover:bg-teal-50/40'
            }`}
          >
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-teal-700 text-white flex items-center justify-center font-black text-2xl shadow-sm shrink-0">
                <HeartHandshake className="w-7 h-7" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-black text-slate-900">2. Caregiver Dashboard</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-800">
                    Decline Alerts
                  </span>
                </div>
                <p className="text-xs font-semibold text-slate-600 mt-0.5">
                  Pranjal Baruah (Son). 30-day Recharts trend, &gt;15% cognitive drop warning, domain breakdown, PDF download.
                </p>
              </div>
            </div>
            <ArrowRight className="w-5 h-5 text-slate-400 shrink-0" />
          </button>

          {/* Demo 3: ASHA Worker */}
          <button
            onClick={() => {
              onSelectRole('asha');
              onClose();
            }}
            className={`w-full p-5 rounded-2xl border-3 text-left transition flex items-center justify-between gap-4 active:scale-98 ${
              currentRole === 'asha'
                ? 'bg-emerald-50 border-emerald-500 ring-2 ring-emerald-300'
                : 'bg-white border-slate-200 hover:border-teal-400 hover:bg-teal-50/40'
            }`}
          >
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-black text-2xl shadow-sm shrink-0">
                <UserCheck className="w-7 h-7" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-black text-slate-900">3. ASHA Health Worker Mode</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    Offline-First
                  </span>
                </div>
                <p className="text-xs font-semibold text-slate-600 mt-0.5">
                  Rani Roy (ASHA Tezpur). Multi-patient triage (Red/Amber/Green), visit note logger, 1-tap data sync.
                </p>
              </div>
            </div>
            <ArrowRight className="w-5 h-5 text-slate-400 shrink-0" />
          </button>
        </div>
      </div>
    </div>
  );
};
