import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Mic, 
  MicOff, 
  Volume2, 
  Users, 
  Languages, 
  HeartHandshake, 
  UserCheck, 
  Home, 
  Gamepad2, 
  Calendar, 
  Image as ImageIcon 
} from 'lucide-react';
import { Role, LanguageCode, PatientProfile } from '../../types';
import { translations } from '../../utils/translations';
import { speechService } from '../../services/speechService';
import { PWAInstallButton } from './PWAInstallButton';

interface HeaderProps {
  currentRole: Role;
  onRoleChange: (role: Role) => void;
  activePatient: PatientProfile;
  allPatients: PatientProfile[];
  onSelectPatient: (patientId: string) => void;
  currentLanguage: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  onTriggerSOS: () => void;
  onNavigate: (view: string) => void;
  currentView: string;
}

const LANGUAGES: { code: LanguageCode; label: string; native: string }[] = [
  { code: 'as', label: 'Assamese', native: 'অসমীয়া' },
  { code: 'bn', label: 'Bengali', native: 'বাংলা' },
  { code: 'brx', label: 'Bodo', native: 'बर’ / बड़ो' },
  { code: 'doi', label: 'Dogri', native: 'डोगरी' },
  { code: 'en', label: 'English', native: 'English' },
  { code: 'grt', label: 'Garo', native: 'A·chik' },
  { code: 'gu', label: 'Gujarati', native: 'ગુજરાતી' },
  { code: 'hi', label: 'Hindi', native: 'हिंदी' },
  { code: 'kn', label: 'Kannada', native: 'ಕನ್ನಡ' },
  { code: 'ks', label: 'Kashmiri', native: 'کٲشُر / کشمیری' },
  { code: 'kha', label: 'Khasi', native: 'Ka Ktien Khasi' },
  { code: 'gom', label: 'Konkani', native: 'कोंकणी' },
  { code: 'mai', label: 'Maithili', native: 'मैथिली' },
  { code: 'ml', label: 'Malayalam', native: 'മലയാളം' },
  { code: 'mni', label: 'Manipuri', native: 'মৈতৈলোন্' },
  { code: 'mr', label: 'Marathi', native: 'मराठी' },
  { code: 'lus', label: 'Mizo', native: 'Mizo ṭawng' },
  { code: 'ne', label: 'Nepali', native: 'नेपाली' },
  { code: 'or', label: 'Odia', native: 'ଓଡ଼ିଆ' },
  { code: 'pa', label: 'Punjabi', native: 'ਪੰਜਾਬੀ' },
  { code: 'sa', label: 'Sanskrit', native: 'संस्कृतम्' },
  { code: 'sat', label: 'Santali', native: 'ᱥᱟᱱᱛᱟᱲᱤ / संताली' },
  { code: 'sd', label: 'Sindhi', native: 'سنڌي / सिंधी' },
  { code: 'ta', label: 'Tamil', native: 'தமிழ்' },
  { code: 'te', label: 'Telugu', native: 'తెలుగు' },
  { code: 'ur', label: 'Urdu', native: 'اردو' },
];

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  onRoleChange,
  activePatient,
  allPatients,
  onSelectPatient,
  currentLanguage,
  onLanguageChange,
  onTriggerSOS,
  onNavigate,
  currentView,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [voiceFeedback, setVoiceFeedback] = useState<string>('');
  const t = translations[currentLanguage] || translations.en;

  const handleVoiceCommand = () => {
    if (isListening) {
      speechService.stopListening();
      setIsListening(false);
      setVoiceFeedback('');
      return;
    }

    setVoiceFeedback('Listening... Say "Play", "Help", or "My Day"');
    setIsListening(true);

    const started = speechService.startListening(currentLanguage, {
      onResult: (phrase: string) => {
        setIsListening(false);
        setVoiceFeedback(`Heard: "${phrase}"`);

        const p = phrase.toLowerCase();
        if (p.includes('play') || p.includes('game') || p.includes('khel') || p.includes('shannaba')) {
          onNavigate('games');
          speechService.speak('Opening cognitive games', currentLanguage);
        } else if (p.includes('help') || p.includes('sos') || p.includes('sahay') || p.includes('pui')) {
          onTriggerSOS();
        } else if (p.includes('day') || p.includes('routine') || p.includes('medicine') || p.includes('dawa')) {
          onNavigate('routine');
          speechService.speak('Opening your daily routine and medicines', currentLanguage);
        } else if (p.includes('family') || p.includes('photo') || p.includes('album') || p.includes('poriyal')) {
          onNavigate('family');
          speechService.speak('Opening your family album', currentLanguage);
        } else if (p.includes('home') || p.includes('ghor') || p.includes('in')) {
          onNavigate('home');
          speechService.speak('Going home', currentLanguage);
        } else {
          speechService.speak(`Understood ${phrase}. You can say Play, Help, or My Day.`, currentLanguage);
        }

        setTimeout(() => setVoiceFeedback(''), 4000);
      },
      onError: () => {
        setIsListening(false);
        setVoiceFeedback('Voice recognition unavailable on this browser. Use buttons.');
        setTimeout(() => setVoiceFeedback(''), 4000);
      },
      onEnd: () => {
        setIsListening(false);
      },
    });

    if (!started) {
      setIsListening(false);
      setVoiceFeedback('Web Speech not supported on this device. Click buttons.');
      setTimeout(() => setVoiceFeedback(''), 4000);
    }
  };

  const handleReadPageAloud = () => {
    let textToSpeak = '';
    if (currentView === 'home' || currentView === 'patient') {
      textToSpeak = `Hello ${activePatient.nickname}. Welcome to MindMate. Tap Play Games to start your daily memory workout, or tap My Day for medicine.`;
    } else if (currentView === 'routine') {
      textToSpeak = `Here is your daily routine, ${activePatient.nickname}. Check your medicines and walk.`;
    } else if (currentView === 'family') {
      textToSpeak = `Here are your loved ones. Tap any photo to hear about them.`;
    } else if (currentView === 'games') {
      textToSpeak = `Choose a gentle memory game. Memory Match, Name the Picture, or Folk Music.`;
    } else {
      textToSpeak = `MindMate cognitive assistance. Always here to help you.`;
    }
    speechService.speak(textToSpeak, currentLanguage);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#0D5C75] text-white shadow-lg border-b border-teal-800/60">
      {/* Top Utility Bar: Role Switcher, Language & SOS */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2 sm:py-2.5 flex flex-wrap items-center justify-between gap-2 border-b border-teal-700/50">
        
        {/* Brand & SIH Logo info */}
        <div className="flex items-center gap-2.5">
          <div 
            onClick={() => onNavigate('home')} 
            className="flex items-center gap-2 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-900 flex items-center justify-center font-extrabold text-xl shadow-md group-hover:rotate-6 transition-transform">
              M
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg sm:text-xl tracking-tight text-white">MindMate</span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-teal-800 text-teal-200 uppercase tracking-widest hidden sm:inline">
                  NER SIH26003
                </span>
              </div>
              <p className="text-[11px] text-teal-200 font-medium hidden md:block">
                Team Algo-X | Dementia Care North East India
              </p>
            </div>
          </div>
        </div>

        {/* Roles Quick Switcher */}
        <div className="flex items-center gap-1 bg-teal-900/60 p-1 rounded-xl border border-teal-700/40 text-xs sm:text-sm">
          <button
            onClick={() => onRoleChange('patient')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition ${
              currentRole === 'patient'
                ? 'bg-amber-400 text-slate-900 shadow-sm'
                : 'text-teal-200 hover:text-white hover:bg-teal-800/50'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Patient</span>
          </button>

          <button
            onClick={() => onRoleChange('caregiver')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition ${
              currentRole === 'caregiver'
                ? 'bg-amber-400 text-slate-900 shadow-sm'
                : 'text-teal-200 hover:text-white hover:bg-teal-800/50'
            }`}
          >
            <HeartHandshake className="w-4 h-4" />
            <span>Caregiver</span>
          </button>

          <button
            onClick={() => onRoleChange('asha')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition ${
              currentRole === 'asha'
                ? 'bg-amber-400 text-slate-900 shadow-sm'
                : 'text-teal-200 hover:text-white hover:bg-teal-800/50'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>ASHA</span>
          </button>
        </div>

        {/* Top Right: Language Dropdown, Install Button, & Big Red SOS */}
        <div className="flex items-center gap-2">
          {/* Language Selector */}
          <div className="relative flex items-center">
            <Languages className="w-4 h-4 absolute left-2.5 text-teal-300 pointer-events-none" />
            <select
              value={currentLanguage}
              onChange={(e) => onLanguageChange(e.target.value as LanguageCode)}
              className="pl-8 pr-2.5 py-1.5 rounded-xl bg-teal-800 text-xs sm:text-sm font-semibold text-white border border-teal-600 focus:ring-2 focus:ring-amber-400 focus:outline-none appearance-none cursor-pointer"
              title="Change Language"
            >
              {LANGUAGES.map((lang) => (
                <option key={lang.code} value={lang.code} className="bg-slate-900 text-white">
                  {lang.native} ({lang.label})
                </option>
              ))}
            </select>
          </div>

          <PWAInstallButton />

          {/* Emergency SOS Button - Highlighted prominently */}
          <button
            onClick={onTriggerSOS}
            className="flex items-center gap-1.5 bg-rose-600 hover:bg-rose-700 active:scale-95 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-black text-white shadow-md transition animate-pulse"
            title="Emergency SOS Alert"
          >
            <ShieldAlert className="w-5 h-5 stroke-[2.5]" />
            <span className="font-extrabold tracking-wide">SOS</span>
          </button>
        </div>
      </div>

      {/* Secondary Bar: Active Patient Selector & Voice Navigation Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2 flex flex-wrap items-center justify-between gap-3 text-sm">
        
        {/* Active Patient Indicator */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-teal-200 font-medium hidden sm:inline">Active Patient:</span>
          <select
            value={activePatient.id}
            onChange={(e) => onSelectPatient(e.target.value)}
            className="bg-teal-800/80 hover:bg-teal-800 border border-teal-600/60 rounded-xl px-3 py-1.5 text-xs sm:text-sm font-bold text-white focus:outline-none cursor-pointer"
          >
            {allPatients.map((p) => (
              <option key={p.id} value={p.id} className="bg-slate-900 text-white">
                {p.name} ({p.nickname}) - {p.state} [{p.status.toUpperCase()}]
              </option>
            ))}
          </select>
        </div>

        {/* Voice-First Controls for Patient */}
        <div className="flex items-center gap-2">
          {/* Read Aloud Button */}
          <button
            onClick={handleReadPageAloud}
            className="flex items-center gap-1.5 bg-teal-800 hover:bg-teal-700 text-teal-100 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition"
            title="Read screen aloud"
          >
            <Volume2 className="w-4 h-4 text-amber-300" />
            <span className="hidden sm:inline">Listen</span>
          </button>

          {/* Big Mic Button */}
          <button
            onClick={handleVoiceCommand}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition shadow-sm ${
              isListening
                ? 'bg-rose-500 text-white animate-bounce'
                : 'bg-amber-400 hover:bg-amber-500 text-slate-900'
            }`}
            title="Voice Commands: Say 'Play', 'Help', 'My Day'"
          >
            {isListening ? <Mic className="w-4 h-4 animate-pulse" /> : <Mic className="w-4 h-4" />}
            <span>{isListening ? 'Listening...' : 'Voice (Mic)'}</span>
          </button>
        </div>
      </div>

      {/* Voice feedback toast banner */}
      {voiceFeedback && (
        <div className="bg-amber-500 text-slate-950 px-4 py-1.5 text-center text-xs sm:text-sm font-bold shadow-inner">
          🎙️ {voiceFeedback}
        </div>
      )}

      {/* Patient Bottom Navigation for quick accessibility */}
      {currentRole === 'patient' && (
        <nav className="bg-teal-950/80 px-2 py-1.5 flex items-center justify-around border-t border-teal-800/80">
          <button
            onClick={() => onNavigate('home')}
            className={`flex flex-col items-center py-1 px-3 rounded-lg text-xs font-bold transition ${
              currentView === 'home' ? 'text-amber-400 bg-teal-800/60' : 'text-teal-200 hover:text-white'
            }`}
          >
            <Home className="w-5 h-5 mb-0.5" />
            <span>{t.home}</span>
          </button>

          <button
            onClick={() => onNavigate('games')}
            className={`flex flex-col items-center py-1 px-3 rounded-lg text-xs font-bold transition ${
              currentView === 'games' ? 'text-amber-400 bg-teal-800/60' : 'text-teal-200 hover:text-white'
            }`}
          >
            <Gamepad2 className="w-5 h-5 mb-0.5" />
            <span>{t.playGame}</span>
          </button>

          <button
            onClick={() => onNavigate('routine')}
            className={`flex flex-col items-center py-1 px-3 rounded-lg text-xs font-bold transition ${
              currentView === 'routine' ? 'text-amber-400 bg-teal-800/60' : 'text-teal-200 hover:text-white'
            }`}
          >
            <Calendar className="w-5 h-5 mb-0.5" />
            <span>{t.myDay}</span>
          </button>

          <button
            onClick={() => onNavigate('family')}
            className={`flex flex-col items-center py-1 px-3 rounded-lg text-xs font-bold transition ${
              currentView === 'family' ? 'text-amber-400 bg-teal-800/60' : 'text-teal-200 hover:text-white'
            }`}
          >
            <ImageIcon className="w-5 h-5 mb-0.5" />
            <span>{t.family}</span>
          </button>
        </nav>
      )}
    </header>
  );
};
