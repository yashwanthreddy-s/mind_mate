import React, { useEffect, useState } from 'react';
import { Phone, CheckCircle, Heart, X, ShieldAlert } from 'lucide-react';
import { PatientProfile } from '../../types';
import { speechService } from '../../services/speechService';
import { soundService } from '../../services/soundService';
import { translations } from '../../utils/translations';

interface SOSModalProps {
  isOpen: boolean;
  onClose: () => void;
  patient: PatientProfile;
}

export const SOSModal: React.FC<SOSModalProps> = ({ isOpen, onClose, patient }) => {
  const [breathePhase, setBreathePhase] = useState<'inhale' | 'hold' | 'exhale'>('inhale');
  const t = translations[patient.language] || translations.en;

  useEffect(() => {
    if (isOpen) {
      soundService.playCalmEmergencyAlert();
      const reassureText = `${patient.nickname || patient.name}, help is coming. You are safe. Your son ${patient.caregiver.name} has been notified. Please sit down and take a gentle breath.`;
      speechService.speak(reassureText, patient.language);

      const interval = setInterval(() => {
        setBreathePhase((prev) => (prev === 'inhale' ? 'hold' : prev === 'hold' ? 'exhale' : 'inhale'));
      }, 3500);

      return () => {
        clearInterval(interval);
        speechService.stopSpeaking();
      };
    }
  }, [isOpen, patient]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 p-4 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-lg rounded-3xl bg-[#FAF8F5] p-6 sm:p-8 text-center shadow-2xl border-4 border-rose-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-200 text-slate-700 hover:bg-slate-300 transition"
          aria-label="Close"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Reassuring badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-rose-100 text-rose-800 text-sm font-bold mb-4">
          <ShieldAlert className="w-5 h-5 text-rose-600 animate-pulse" />
          <span>Caregiver & ASHA Worker Notified</span>
        </div>

        {/* Big Soothing Heart */}
        <div className="mx-auto my-3 flex h-24 w-24 items-center justify-center rounded-full bg-rose-50 border-4 border-rose-400 shadow-inner">
          <Heart className="w-12 h-12 text-rose-600 animate-bounce" />
        </div>

        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2">
          {t.helpIsComing}
        </h2>

        <p className="mt-3 text-lg font-medium text-slate-700 leading-relaxed">
          {patient.caregiver.name} ({patient.caregiver.relation}) and Dr. Bhupen Barman have been sent an alert with your location.
        </p>

        {/* Calming breathing guide for elderly panic prevention */}
        <div className="my-6 p-4 rounded-2xl bg-teal-50/80 border border-teal-200">
          <p className="text-xs font-semibold text-teal-800 uppercase tracking-wider mb-2">
            Gentle Calming Breath
          </p>
          <div className="flex items-center justify-center gap-3">
            <div
              className={`h-12 w-12 rounded-full bg-teal-500 transition-all duration-1000 flex items-center justify-center text-white font-bold text-xs shadow-md ${
                breathePhase === 'inhale'
                  ? 'scale-125 bg-teal-600'
                  : breathePhase === 'hold'
                  ? 'scale-110 bg-amber-500'
                  : 'scale-90 bg-teal-400'
              }`}
            >
              {breathePhase === 'inhale' ? 'Breathe In' : breathePhase === 'hold' ? 'Hold' : 'Breathe Out'}
            </div>
            <p className="text-base font-semibold text-teal-900 text-left">
              {t.staySeated}
            </p>
          </div>
        </div>

        {/* Emergency Action Buttons */}
        <div className="space-y-3 mt-4">
          <a
            href={`tel:${patient.caregiver.phone}`}
            className="flex w-full items-center justify-center gap-3 rounded-2xl bg-rose-600 hover:bg-rose-700 py-4 px-6 text-xl font-extrabold text-white shadow-lg transition active:scale-98"
          >
            <Phone className="w-6 h-6 animate-pulse" />
            <span>{t.callNow} ({patient.caregiver.name})</span>
          </a>

          <button
            onClick={onClose}
            className="flex w-full items-center justify-center gap-2 rounded-2xl border-2 border-slate-300 bg-white hover:bg-slate-100 py-3.5 px-6 text-base font-bold text-slate-700 transition"
          >
            <CheckCircle className="w-5 h-5 text-emerald-600" />
            <span>{t.cancelEmergency}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
