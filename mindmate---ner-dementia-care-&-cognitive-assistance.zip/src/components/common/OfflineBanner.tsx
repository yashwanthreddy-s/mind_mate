import React from 'react';
import { WifiOff, RefreshCw } from 'lucide-react';
import { useOnlineStatus } from '../../hooks/useOnlineStatus';

interface OfflineBannerProps {
  onSync?: () => void;
  syncing?: boolean;
}

export const OfflineBanner: React.FC<OfflineBannerProps> = ({ onSync, syncing }) => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="bg-amber-600 text-white px-4 py-2 flex items-center justify-between text-xs sm:text-sm font-medium shadow-md">
      <div className="flex items-center gap-2">
        <WifiOff className="w-4 h-4 shrink-0 animate-pulse" />
        <span>Offline Mode: All cognitive games and screening records work locally.</span>
      </div>
      {onSync && (
        <button
          onClick={onSync}
          disabled={syncing}
          className="flex items-center gap-1.5 bg-amber-700 hover:bg-amber-800 px-2.5 py-1 rounded-lg text-xs font-bold transition disabled:opacity-50 shrink-0"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`} />
          <span>{syncing ? 'Syncing...' : 'Sync'}</span>
        </button>
      )}
    </div>
  );
};
