import React, { useState } from 'react';
import {
  UserCheck,
  RefreshCw,
  Search,
  Filter,
  AlertTriangle,
  CheckCircle2,
  Clock,
  MapPin,
  FilePlus2,
  Download,
  Calendar,
  Phone,
  Eye,
  Check,
  Sparkles,
  WifiOff,
} from 'lucide-react';
import { PatientProfile, AshaVisitNote } from '../../types';
import { StorageService } from '../../services/storage';
import { ReportGenerator } from '../../services/reportGenerator';
import { useOnlineStatus } from '../../hooks/useOnlineStatus';

interface AshaDashboardProps {
  allPatients: PatientProfile[];
  onSelectPatient: (patientId: string) => void;
  onViewPatientAsCaregiver: (patientId: string) => void;
}

export const AshaDashboard: React.FC<AshaDashboardProps> = ({
  allPatients,
  onSelectPatient,
  onViewPatientAsCaregiver,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'red' | 'amber' | 'green'>('all');
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatusMsg, setSyncStatusMsg] = useState('');
  const [lastSync, setLastSync] = useState(StorageService.getLastSyncTime());
  const [notes, setNotes] = useState<AshaVisitNote[]>(StorageService.getAshaNotes());

  // New Visit Note Form state
  const [selectedPatientForNote, setSelectedPatientForNote] = useState<string>(allPatients[0]?.id || 'p1');
  const [visitMood, setVisitMood] = useState<'Calm' | 'Cheerful' | 'Agitated' | 'Confused' | 'Withdrawn'>('Calm');
  const [medAdherence, setMedAdherence] = useState<'Taken' | 'Missed' | 'Assisted'>('Taken');
  const [observationText, setObservationText] = useState('');
  const [noteSuccess, setNoteSuccess] = useState(false);

  const isOnline = useOnlineStatus();

  const handleSyncRecords = () => {
    setIsSyncing(true);
    setSyncStatusMsg('Connecting to District Health Server...');

    setTimeout(() => {
      const result = StorageService.syncAshaRecords();
      setIsSyncing(false);
      setLastSync(result.timestamp);
      setNotes(StorageService.getAshaNotes());
      setSyncStatusMsg(`Successfully synced ${result.count} records to National Health Mission cloud.`);
      setTimeout(() => setSyncStatusMsg(''), 5000);
    }, 1200);
  };

  const handleAddVisitNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!observationText.trim()) return;

    const patient = allPatients.find((p) => p.id === selectedPatientForNote);
    const newNote = StorageService.addAshaNote({
      patientId: selectedPatientForNote,
      patientName: patient?.name || 'Patient',
      date: new Date().toISOString().split('T')[0],
      ashaName: 'Rani Roy (ASHA Tezpur Block)',
      mood: visitMood,
      medicationAdherence: medAdherence,
      observation: observationText,
    });

    setNotes([newNote, ...notes]);
    setObservationText('');
    setNoteSuccess(true);
    setTimeout(() => setNoteSuccess(false), 3500);
  };

  const filteredPatients = allPatients.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.state.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || p.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 animate-fadeIn">
      {/* Header Banner with Offline Indicator & Sync Button */}
      <div className="bg-gradient-to-r from-teal-900 to-[#0D5C75] text-white rounded-3xl p-6 sm:p-8 shadow-md mb-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border-3 border-teal-800">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs font-black uppercase tracking-wider bg-amber-400 text-slate-900 px-3 py-1 rounded-full">
              ASHA Telehealth Portal
            </span>
            <span className="text-xs text-teal-200 font-semibold">
              Team Algo-X (SIH26003)
            </span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black">
            Community Elder Triage
          </h1>
          <p className="text-teal-100 font-medium text-sm sm:text-base mt-1">
            Supervising {allPatients.length} rural dementia patients in Assam, Mizoram & Manipur.
          </p>
          <div className="flex items-center gap-3 mt-3 text-xs text-teal-200">
            <Clock className="w-4 h-4" />
            <span>Last Synced: {new Date(lastSync).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</span>
            <span className="opacity-40">•</span>
            <span>{isOnline ? 'Network Active' : 'Offline Storage (IndexedDB)'}</span>
          </div>
        </div>

        {/* Sync Offline Button */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full md:w-auto">
          <button
            onClick={handleSyncRecords}
            disabled={isSyncing}
            className="flex items-center justify-center gap-2 bg-amber-400 hover:bg-amber-500 text-slate-950 px-6 py-3.5 rounded-2xl font-black text-sm sm:text-base shadow-md transition active:scale-95 disabled:opacity-50"
          >
            <RefreshCw className={`w-5 h-5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Syncing...' : 'Sync Offline Data'}</span>
          </button>
        </div>
      </div>

      {syncStatusMsg && (
        <div className="mb-6 p-4 rounded-2xl bg-emerald-100 border-2 border-emerald-400 text-emerald-950 font-bold text-sm flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0" />
          <span>{syncStatusMsg}</span>
        </div>
      )}

      {/* Patient Triage Summary Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <button
          onClick={() => setStatusFilter(statusFilter === 'red' ? 'all' : 'red')}
          className={`p-5 rounded-3xl border-3 text-left transition ${
            statusFilter === 'red'
              ? 'bg-rose-100 border-rose-500 shadow-md'
              : 'bg-rose-50/70 border-rose-200 hover:border-rose-400'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-black uppercase text-rose-800">Critical Alert</span>
            <span className="w-3 h-3 rounded-full bg-rose-600 animate-pulse" />
          </div>
          <p className="text-3xl font-black text-rose-950 mt-1">
            {allPatients.filter((p) => p.status === 'red').length} Patients
          </p>
          <p className="text-xs text-rose-800 font-bold mt-1">&gt;15% score drop (Immediate visit)</p>
        </button>

        <button
          onClick={() => setStatusFilter(statusFilter === 'amber' ? 'all' : 'amber')}
          className={`p-5 rounded-3xl border-3 text-left transition ${
            statusFilter === 'amber'
              ? 'bg-amber-100 border-amber-500 shadow-md'
              : 'bg-amber-50/70 border-amber-200 hover:border-amber-400'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-black uppercase text-amber-800">Watch Closely</span>
            <span className="w-3 h-3 rounded-full bg-amber-500" />
          </div>
          <p className="text-3xl font-black text-amber-950 mt-1">
            {allPatients.filter((p) => p.status === 'amber').length} Patients
          </p>
          <p className="text-xs text-amber-800 font-bold mt-1">Fluctuating scores (-5% to -15%)</p>
        </button>

        <button
          onClick={() => setStatusFilter(statusFilter === 'green' ? 'all' : 'green')}
          className={`p-5 rounded-3xl border-3 text-left transition ${
            statusFilter === 'green'
              ? 'bg-emerald-100 border-emerald-500 shadow-md'
              : 'bg-emerald-50/70 border-emerald-200 hover:border-emerald-400'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-black uppercase text-emerald-800">Cognitive Stable</span>
            <span className="w-3 h-3 rounded-full bg-emerald-500" />
          </div>
          <p className="text-3xl font-black text-emerald-950 mt-1">
            {allPatients.filter((p) => p.status === 'green').length} Patients
          </p>
          <p className="text-xs text-emerald-800 font-bold mt-1">Routine monthly screening</p>
        </button>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 shadow-sm border-2 border-teal-100 mb-8 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-96">
          <Search className="w-5 h-5 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="Search by patient name, district, or state..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-50 border border-slate-300 text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-600"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <Filter className="w-4 h-4 text-slate-500" />
          <span className="text-xs font-bold text-slate-600">Filter:</span>
          {(['all', 'red', 'amber', 'green'] as const).map((filter) => (
            <button
              key={filter}
              onClick={() => setStatusFilter(filter)}
              className={`px-3 py-1.5 rounded-xl text-xs font-extrabold capitalize transition ${
                statusFilter === filter
                  ? 'bg-teal-800 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>
      </div>

      {/* Patient Cards List */}
      <div className="space-y-4 mb-10">
        {filteredPatients.map((patient) => {
          const isRed = patient.status === 'red';
          const isAmber = patient.status === 'amber';

          return (
            <div
              key={patient.id}
              className={`p-6 rounded-3xl border-3 shadow-sm transition-all bg-white flex flex-col md:flex-row items-start md:items-center justify-between gap-6 ${
                isRed
                  ? 'border-rose-400 hover:shadow-rose-100'
                  : isAmber
                  ? 'border-amber-300 hover:shadow-amber-100'
                  : 'border-emerald-300 hover:shadow-emerald-100'
              }`}
            >
              <div className="flex items-start gap-4">
                <img
                  src={patient.avatarUrl}
                  alt={patient.name}
                  className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border-3 border-slate-200 shrink-0"
                />

                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-xl sm:text-2xl font-black text-slate-900">
                      {patient.name} ({patient.nickname})
                    </h3>
                    <span
                      className={`text-xs font-extrabold uppercase px-3 py-0.5 rounded-full ${
                        isRed
                          ? 'bg-rose-100 text-rose-800 border border-rose-300'
                          : isAmber
                          ? 'bg-amber-100 text-amber-800 border border-amber-300'
                          : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      }`}
                    >
                      {isRed ? 'Decline Alert' : isAmber ? 'Watch' : 'Stable'}
                    </span>
                  </div>

                  <p className="text-sm font-semibold text-slate-600 mt-1">
                    Age {patient.age} • {patient.diagnosis} • {patient.location}
                  </p>

                  <p className="text-xs text-slate-700 font-bold mt-1 bg-slate-50 p-2 rounded-xl border border-slate-200">
                    {patient.statusReason || 'Baseline maintained.'}
                  </p>
                </div>
              </div>

              {/* Score & Actions */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 w-full md:w-auto justify-between md:justify-end">
                <div className="text-left sm:text-right">
                  <span className="text-xs font-bold text-slate-500 uppercase">Score (Trend)</span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl sm:text-3xl font-black text-slate-900">
                      {patient.currentScore}
                    </span>
                    <span
                      className={`text-sm font-extrabold ${
                        patient.scoreChangePct < -15
                          ? 'text-rose-600'
                          : patient.scoreChangePct < 0
                          ? 'text-amber-600'
                          : 'text-emerald-600'
                      }`}
                    >
                      ({patient.scoreChangePct > 0 ? '+' : ''}
                      {patient.scoreChangePct}%)
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    onClick={() => onViewPatientAsCaregiver(patient.id)}
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 bg-teal-50 hover:bg-teal-100 text-teal-900 border border-teal-200 px-3.5 py-2.5 rounded-xl text-xs font-bold transition"
                  >
                    <Eye className="w-4 h-4" />
                    <span>View Analytics</span>
                  </button>

                  <button
                    onClick={() => ReportGenerator.generatePatientPDF(patient)}
                    className="p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition"
                    title="Download Report (PDF)"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* ASHA Home Visit Note Logger */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border-2 border-teal-100 mb-8">
        <div className="flex items-center gap-2 mb-4">
          <FilePlus2 className="w-6 h-6 text-teal-700" />
          <h2 className="text-2xl font-black text-slate-900">
            Log ASHA Home Visit Note (Offline Ready)
          </h2>
        </div>

        <form onSubmit={handleAddVisitNote} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                Select Patient
              </label>
              <select
                value={selectedPatientForNote}
                onChange={(e) => setSelectedPatientForNote(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-300 text-sm font-bold text-slate-800 bg-white"
              >
                {allPatients.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.location})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                Observed Mood
              </label>
              <select
                value={visitMood}
                onChange={(e) => setVisitMood(e.target.value as any)}
                className="w-full p-2.5 rounded-xl border border-slate-300 text-sm font-bold text-slate-800 bg-white"
              >
                <option value="Calm">Calm & Responsive</option>
                <option value="Cheerful">Cheerful & Engaged</option>
                <option value="Confused">Confused / Disoriented</option>
                <option value="Agitated">Agitated / Restless</option>
                <option value="Withdrawn">Withdrawn / Quiet</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                Medication Adherence
              </label>
              <select
                value={medAdherence}
                onChange={(e) => setMedAdherence(e.target.value as any)}
                className="w-full p-2.5 rounded-xl border border-slate-300 text-sm font-bold text-slate-800 bg-white"
              >
                <option value="Taken">Taken on schedule</option>
                <option value="Assisted">Assisted by caregiver</option>
                <option value="Missed">Missed morning dose</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
              Clinical & Social Observation
            </label>
            <textarea
              rows={3}
              value={observationText}
              onChange={(e) => setObservationText(e.target.value)}
              placeholder="e.g. Visited patient home. Sang Assamese Bihu naam together; patient smiled and recognized son. Checked BP: 124/80."
              className="w-full p-3 rounded-xl border border-slate-300 text-sm text-slate-800 font-medium focus:ring-2 focus:ring-teal-600 focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-between">
            {noteSuccess && (
              <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-3 py-1 rounded-full flex items-center gap-1">
                <Check className="w-4 h-4" /> Note stored offline and queued for sync!
              </span>
            )}
            <button
              type="submit"
              className="ml-auto bg-teal-700 hover:bg-teal-800 text-white font-bold text-sm px-6 py-2.5 rounded-xl shadow-xs transition"
            >
              Save Visit Note
            </button>
          </div>
        </form>

        {/* Existing Notes Feed */}
        <div className="mt-8 pt-6 border-t border-slate-100">
          <h3 className="text-base font-black text-slate-900 mb-3">
            Recent Field Visit Notes ({notes.length})
          </h3>
          <div className="space-y-3">
            {notes.map((note) => (
              <div key={note.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
                  <span className="font-extrabold text-teal-800">{note.patientName}</span>
                  <div className="flex items-center gap-2">
                    <span>{note.date}</span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        note.synced ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {note.synced ? 'Cloud Synced' : 'Queued (Offline)'}
                    </span>
                  </div>
                </div>
                <p className="text-sm font-medium text-slate-800">{note.observation}</p>
                <div className="flex items-center gap-3 mt-2 text-xs font-semibold text-slate-600">
                  <span>Mood: <strong>{note.mood}</strong></span>
                  <span>•</span>
                  <span>Meds: <strong>{note.medicationAdherence}</strong></span>
                  <span>•</span>
                  <span>Staff: {note.ashaName}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
