import React, { useState } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  BarChart,
  Bar,
  Legend,
} from 'recharts';
import {
  ShieldAlert,
  Download,
  AlertTriangle,
  TrendingDown,
  TrendingUp,
  Brain,
  Calendar,
  Phone,
  CheckCircle2,
  FileText,
  UserCheck,
  HeartHandshake,
  Activity,
  Sparkles,
} from 'lucide-react';
import { PatientProfile, DailyCognitiveScore, DeclineAlert } from '../../types';
import { CognitiveEngine } from '../../services/cognitiveEngine';
import { StorageService } from '../../services/storage';
import { ReportGenerator } from '../../services/reportGenerator';
import { translations } from '../../utils/translations';

interface CaregiverDashboardProps {
  patient: PatientProfile;
  allPatients: PatientProfile[];
  onSelectPatient: (patientId: string) => void;
  onUpdatePatient: (updated: PatientProfile) => void;
}

export const CaregiverDashboard: React.FC<CaregiverDashboardProps> = ({
  patient,
  allPatients,
  onSelectPatient,
  onUpdatePatient,
}) => {
  const [timeRange, setTimeRange] = useState<'7' | '30'>('30');
  const [consentGiven, setConsentGiven] = useState(patient.consentGiven);
  const [downloadingPdf, setDownloadingPdf] = useState(false);

  const scores = StorageService.getPatientScores(patient.id);
  const analysis = CognitiveEngine.analyzePatient(patient);
  const alerts = StorageService.getAlerts().filter((a) => a.patientId === patient.id);

  const chartData = (timeRange === '7' ? scores.slice(-7) : scores).map((s) => ({
    date: s.date.slice(5), // MM-DD
    fullDate: s.date,
    Score: s.overallScore,
    Memory: s.domainScores.memory,
    Attention: s.domainScores.attention,
    Orientation: s.domainScores.orientation,
    Language: s.domainScores.language,
  }));

  const domainBarData = [
    { domain: 'Memory (35%)', score: analysis.domainScores.memory, target: 80 },
    { domain: 'Attention (25%)', score: analysis.domainScores.attention, target: 75 },
    { domain: 'Orientation (20%)', score: analysis.domainScores.orientation, target: 85 },
    { domain: 'Language (20%)', score: analysis.domainScores.language, target: 80 },
  ];

  const handleToggleConsent = () => {
    const updated = !consentGiven;
    setConsentGiven(updated);
    const updatedPatient = { ...patient, consentGiven: updated };
    StorageService.updatePatient(updatedPatient);
    onUpdatePatient(updatedPatient);
  };

  const handleDownloadPDF = () => {
    setDownloadingPdf(true);
    try {
      ReportGenerator.generatePatientPDF(patient);
    } finally {
      setTimeout(() => setDownloadingPdf(false), 800);
    }
  };

  const handleAcknowledgeAlert = (alertId: string) => {
    StorageService.acknowledgeAlert(alertId);
    // Trigger local state re-render
    onUpdatePatient({ ...patient });
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 animate-fadeIn">
      {/* Top Banner: Patient Overview & One-Tap PDF Report Download */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border-2 border-teal-100 mb-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <img
            src={patient.avatarUrl}
            alt={patient.name}
            className="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl object-cover border-4 border-amber-300 shadow-sm"
          />
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-2xl sm:text-3xl font-black text-slate-900">
                {patient.name} ({patient.nickname})
              </h1>
              <span
                className={`text-xs font-black uppercase px-3 py-1 rounded-full ${
                  patient.status === 'red'
                    ? 'bg-rose-100 text-rose-800 border border-rose-300'
                    : patient.status === 'amber'
                    ? 'bg-amber-100 text-amber-800 border border-amber-300'
                    : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                }`}
              >
                {patient.status === 'red' ? 'Decline Alert' : patient.status === 'amber' ? 'Watch Closely' : 'Stable'}
              </span>
            </div>

            <p className="text-slate-600 font-medium text-sm sm:text-base mt-1">
              Age {patient.age} • {patient.diagnosis} • {patient.location}, {patient.state}
            </p>
            <p className="text-xs text-slate-500 font-semibold mt-0.5">
              Caregiver: {patient.caregiver.name} ({patient.caregiver.relation}) • {patient.caregiver.phone}
            </p>
          </div>
        </div>

        {/* Download PDF Button */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full md:w-auto">
          <button
            onClick={handleDownloadPDF}
            disabled={downloadingPdf}
            className="flex items-center justify-center gap-2 bg-teal-700 hover:bg-teal-800 text-white px-5 py-3 rounded-2xl font-extrabold text-sm sm:text-base shadow-md transition active:scale-95 disabled:opacity-50"
          >
            <Download className="w-5 h-5" />
            <span>{downloadingPdf ? 'Generating PDF...' : 'Download Clinical PDF Report'}</span>
          </button>
        </div>
      </div>

      {/* Critical Decline Alert Banner if triggered */}
      {analysis.isDeclineTriggered && (
        <div className="bg-rose-50 border-4 border-rose-400 rounded-3xl p-6 sm:p-7 mb-8 shadow-sm animate-fadeIn">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-rose-600 text-white rounded-2xl shrink-0">
              <AlertTriangle className="w-8 h-8" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <span className="text-xs font-black uppercase tracking-wider bg-rose-200 text-rose-900 px-3 py-0.5 rounded-full">
                  AI Decline Detection Triggered
                </span>
                <span className="text-xs font-bold text-rose-700">Threshold: &gt;15% Drop</span>
              </div>

              <h2 className="text-xl sm:text-2xl font-black text-rose-950 mt-1">
                Significant 7-Day Cognitive Drop Detected ({analysis.percentageChange}% Drop)
              </h2>

              <p className="text-rose-900 text-base font-medium mt-1 leading-relaxed">
                {patient.nickname}'s 7-day average score has dropped to{' '}
                <strong>{analysis.recent7DayAvg}/100</strong> compared to her 14-day established baseline of{' '}
                <strong>{analysis.baseline14DayAvg}/100</strong>. Primary decline is observed in visual memory match and sequence recall.
              </p>

              <div className="mt-4 p-4 rounded-2xl bg-white border border-rose-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <p className="text-xs font-bold uppercase text-slate-500">Recommended Clinical Action</p>
                  <p className="text-sm font-extrabold text-slate-800">
                    Notify Dr. Bhupen Barman (Tezpur Medical College) and local ASHA worker Rani Roy for home evaluation.
                  </p>
                </div>
                <a
                  href={`tel:${patient.emergencyContacts[1]?.phone || '+919864044221'}`}
                  className="bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-xs shrink-0 transition"
                >
                  Call Physician Now
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4 Score Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {/* Metric 1: Current Score */}
        <div className="bg-white rounded-3xl p-5 shadow-sm border-2 border-slate-200 flex flex-col justify-between">
          <span className="text-xs font-bold uppercase text-slate-500">Current Daily Score</span>
          <div className="my-2 flex items-baseline gap-2">
            <span className="text-4xl font-black text-slate-900">{analysis.dailyScore}</span>
            <span className="text-slate-400 font-bold text-base">/ 100</span>
          </div>
          <span className="text-xs font-semibold text-slate-600">Weighted across 4 domains</span>
        </div>

        {/* Metric 2: 14-Day Baseline */}
        <div className="bg-white rounded-3xl p-5 shadow-sm border-2 border-slate-200 flex flex-col justify-between">
          <span className="text-xs font-bold uppercase text-slate-500">14-Day Baseline</span>
          <div className="my-2 flex items-baseline gap-2">
            <span className="text-4xl font-black text-teal-800">{analysis.baseline14DayAvg}</span>
            <span className="text-slate-400 font-bold text-base">/ 100</span>
          </div>
          <span className="text-xs font-semibold text-teal-700">Patient's historical norm</span>
        </div>

        {/* Metric 3: Recent 7-Day Average */}
        <div className="bg-white rounded-3xl p-5 shadow-sm border-2 border-slate-200 flex flex-col justify-between">
          <span className="text-xs font-bold uppercase text-slate-500">Recent 7-Day Average</span>
          <div className="my-2 flex items-baseline gap-2">
            <span
              className={`text-4xl font-black ${
                analysis.isDeclineTriggered ? 'text-rose-600' : 'text-slate-900'
              }`}
            >
              {analysis.recent7DayAvg}
            </span>
            <span className="text-slate-400 font-bold text-base">/ 100</span>
          </div>
          <span className="text-xs font-semibold text-slate-600">Rolling cognitive health</span>
        </div>

        {/* Metric 4: Score Variation (%) */}
        <div
          className={`rounded-3xl p-5 shadow-sm border-2 flex flex-col justify-between ${
            analysis.isDeclineTriggered
              ? 'bg-rose-50 border-rose-300'
              : 'bg-white border-slate-200'
          }`}
        >
          <span className="text-xs font-bold uppercase text-slate-500">Baseline Variation</span>
          <div className="my-2 flex items-center gap-2">
            {analysis.percentageChange < 0 ? (
              <TrendingDown className="w-8 h-8 text-rose-600" />
            ) : (
              <TrendingUp className="w-8 h-8 text-emerald-600" />
            )}
            <span
              className={`text-4xl font-black ${
                analysis.percentageChange < -15
                  ? 'text-rose-600'
                  : analysis.percentageChange < 0
                  ? 'text-amber-600'
                  : 'text-emerald-600'
              }`}
            >
              {analysis.percentageChange > 0 ? '+' : ''}
              {analysis.percentageChange}%
            </span>
          </div>
          <span className="text-xs font-semibold text-slate-600">
            {analysis.isDeclineTriggered ? 'Decline limit exceeded (>15%)' : 'Within normal variance'}
          </span>
        </div>
      </div>

      {/* Interactive Score Trend Chart with Recharts */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border-2 border-teal-100 mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900">
              Cognitive Score Trajectory
            </h3>
            <p className="text-sm text-slate-500 font-medium mt-0.5">
              Showing 14-day baseline and 15% decline threshold reference lines
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setTimeRange('7')}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold transition ${
                timeRange === '7' ? 'bg-teal-700 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Last 7 Days
            </button>
            <button
              onClick={() => setTimeRange('30')}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold transition ${
                timeRange === '30' ? 'bg-teal-700 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Full 30 Days
            </button>
          </div>
        </div>

        <div className="h-72 sm:h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="date" stroke="#94A3B8" fontSize={12} tickLine={false} />
              <YAxis domain={[40, 100]} stroke="#94A3B8" fontSize={12} tickLine={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#FFFFFF',
                  borderRadius: '16px',
                  border: '2px solid #E2E8F0',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
                }}
              />
              <Legend verticalAlign="top" height={36} />

              {/* Baseline reference line */}
              <ReferenceLine
                y={analysis.baseline14DayAvg}
                stroke="#0D5C75"
                strokeDasharray="5 5"
                label={{ value: `Baseline: ${analysis.baseline14DayAvg}`, fill: '#0D5C75', fontSize: 11 }}
              />

              {/* Decline Alert Threshold Line (-15%) */}
              <ReferenceLine
                y={Math.round(analysis.baseline14DayAvg * 0.85)}
                stroke="#E11D48"
                strokeDasharray="3 3"
                label={{ value: 'Decline Threshold (-15%)', fill: '#E11D48', fontSize: 11 }}
              />

              <Line
                type="monotone"
                dataKey="Score"
                stroke="#0D5C75"
                strokeWidth={3.5}
                dot={{ r: 3, fill: '#0D5C75' }}
                activeDot={{ r: 6 }}
              />
              <Line
                type="monotone"
                dataKey="Memory"
                stroke="#F59E0B"
                strokeWidth={2}
                strokeDasharray="4 4"
                dot={false}
              />
              <Line
                type="monotone"
                dataKey="Attention"
                stroke="#3B82F6"
                strokeWidth={2}
                strokeDasharray="4 4"
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Domain Breakdown & Alert Log Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        
        {/* Domain Breakdown Chart */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border-2 border-teal-100">
          <div className="flex items-center gap-2 mb-4">
            <Brain className="w-6 h-6 text-teal-700" />
            <h3 className="text-xl font-black text-slate-900">
              Cognitive Domain Performance
            </h3>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={domainBarData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                <XAxis dataKey="domain" stroke="#64748B" fontSize={11} tickLine={false} />
                <YAxis domain={[0, 100]} stroke="#64748B" fontSize={11} tickLine={false} />
                <Tooltip />
                <Bar dataKey="score" name="Patient Score" fill="#0D5C75" radius={[8, 8, 0, 0]} />
                <Bar dataKey="target" name="Typical Target" fill="#CBD5E1" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Decline Alerts & Notifications */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border-2 border-teal-100">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-6 h-6 text-rose-600" />
              <h3 className="text-xl font-black text-slate-900">
                Cognitive Decline Alerts
              </h3>
            </div>
            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700">
              {alerts.length} Logged
            </span>
          </div>

          <div className="space-y-3.5 max-h-72 overflow-y-auto pr-1">
            {alerts.length === 0 ? (
              <p className="text-sm text-slate-500 font-medium py-6 text-center">
                No active decline alerts for this patient.
              </p>
            ) : (
              alerts.map((alert) => (
                <div
                  key={alert.id}
                  className={`p-4 rounded-2xl border-2 transition ${
                    alert.severity === 'red'
                      ? 'bg-rose-50/70 border-rose-300 text-rose-950'
                      : 'bg-amber-50/70 border-amber-300 text-amber-950'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-xs font-black uppercase tracking-wider">
                      [{alert.severity.toUpperCase()}] {alert.date}
                    </span>
                    {alert.acknowledged ? (
                      <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                        Reviewed
                      </span>
                    ) : (
                      <button
                        onClick={() => handleAcknowledgeAlert(alert.id)}
                        className="text-[11px] font-bold text-white bg-slate-800 hover:bg-slate-900 px-2.5 py-0.5 rounded-full transition"
                      >
                        Acknowledge
                      </button>
                    )}
                  </div>

                  <h4 className="font-extrabold text-base mt-1">{alert.title}</h4>
                  <p className="text-xs mt-1 leading-relaxed opacity-90">{alert.description}</p>
                  <p className="text-xs font-bold mt-2 text-teal-900 bg-white/70 p-2 rounded-xl">
                    Action: {alert.recommendedAction}
                  </p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Patient Profile, Consent & Emergency Contacts */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border-2 border-teal-100">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4 mb-6">
          <div>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900">
              Caregiver Consent & Emergency Protocols
            </h3>
            <p className="text-sm text-slate-500 font-medium">
              Verified legal consent for AI cognitive screening in North East India rural telehealth network
            </p>
          </div>

          {/* Consent Toggle */}
          <div className="flex items-center gap-3 bg-teal-50 p-3 rounded-2xl border border-teal-200">
            <span className="text-xs font-bold text-teal-900">
              Telehealth Consent: {consentGiven ? 'GRANTED' : 'REVOKED'}
            </span>
            <button
              onClick={handleToggleConsent}
              className={`w-12 h-7 rounded-full p-1 transition-colors ${
                consentGiven ? 'bg-emerald-600' : 'bg-slate-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  consentGiven ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Emergency Contacts List */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {patient.emergencyContacts.map((contact, idx) => (
            <div key={idx} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                  {contact.relation}
                </span>
                <p className="font-extrabold text-slate-900 text-base mt-0.5">{contact.name}</p>
              </div>
              <a
                href={`tel:${contact.phone}`}
                className="mt-3 inline-flex items-center gap-2 text-xs font-bold text-teal-800 bg-white hover:bg-teal-50 border border-slate-200 py-2 px-3 rounded-xl transition"
              >
                <Phone className="w-3.5 h-3.5 text-teal-700" />
                <span>{contact.phone}</span>
              </a>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
