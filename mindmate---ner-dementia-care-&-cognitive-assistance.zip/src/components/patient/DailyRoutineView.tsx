import React, { useState } from 'react';
import { ArrowLeft, CheckCircle2, Circle, Clock, Pill, Coffee, Footprints, Utensils, PhoneCall, Volume2, Sparkles } from 'lucide-react';
import { PatientProfile, RoutineItem } from '../../types';
import { soundService } from '../../services/soundService';
import { speechService } from '../../services/speechService';
import { StorageService } from '../../services/storage';
import { translations } from '../../utils/translations';

interface DailyRoutineViewProps {
  patient: PatientProfile;
  onBack: () => void;
}

export const DailyRoutineView: React.FC<DailyRoutineViewProps> = ({ patient, onBack }) => {
  const [routineItems, setRoutineItems] = useState<RoutineItem[]>(patient.dailyRoutine);
  const t = translations[patient.language] || translations.en;

  const toggleComplete = (id: string) => {
    const updated = routineItems.map((item) => {
      if (item.id === id) {
        const nextState = !item.completed;
        if (nextState) {
          soundService.playSuccess();
          speechService.speak(`${item.title} completed with love and care!`, patient.language);
        }
        return { ...item, completed: nextState };
      }
      return item;
    });

    setRoutineItems(updated);
    const updatedPatient = { ...patient, dailyRoutine: updated };
    StorageService.updatePatient(updatedPatient);
  };

  const speakItem = (item: RoutineItem, e: React.MouseEvent) => {
    e.stopPropagation();
    speechService.speak(
      `At ${item.time}: ${item.title}. ${item.description}. ${item.completed ? 'Already completed.' : 'Needs to be done.'}`,
      patient.language
    );
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'medicine':
        return <Pill className="w-7 h-7 text-rose-600" />;
      case 'meal':
        return <Utensils className="w-7 h-7 text-amber-600" />;
      case 'activity':
        return <Footprints className="w-7 h-7 text-teal-600" />;
      default:
        return <Coffee className="w-7 h-7 text-teal-600" />;
    }
  };

  const completedCount = routineItems.filter((i) => i.completed).length;

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 animate-fadeIn">
      {/* Top Header */}
      <div className="flex items-center justify-between gap-3 mb-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 bg-white hover:bg-slate-100 px-4 py-2.5 rounded-2xl border-2 border-slate-200 text-slate-800 font-bold shadow-sm transition active:scale-95 text-base sm:text-lg"
        >
          <ArrowLeft className="w-6 h-6 text-teal-700" />
          <span>{t.home}</span>
        </button>

        <div className="flex items-center gap-2 bg-teal-50 px-4 py-2 rounded-2xl border border-teal-200">
          <span className="text-xs font-bold text-teal-700 uppercase">Progress</span>
          <span className="text-lg font-black text-teal-900">
            {completedCount} / {routineItems.length}
          </span>
        </div>
      </div>

      {/* Routine Title */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 mb-6 shadow-sm border-2 border-teal-100">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 flex items-center justify-center text-amber-700">
            <Clock className="w-7 h-7" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900">
              {t.myDay}
            </h1>
            <p className="text-slate-600 font-medium text-base mt-0.5">
              Familiar daily routine for {patient.nickname} in {patient.location}
            </p>
          </div>
        </div>
      </div>

      {/* Routine list with huge tap targets */}
      <div className="space-y-4">
        {routineItems.map((item) => (
          <div
            key={item.id}
            onClick={() => toggleComplete(item.id)}
            className={`p-5 sm:p-6 rounded-3xl border-3 transition-all cursor-pointer shadow-sm flex items-start justify-between gap-4 select-none ${
              item.completed
                ? 'bg-emerald-50/70 border-emerald-300'
                : 'bg-white border-slate-200 hover:border-teal-400 hover:shadow-md'
            }`}
          >
            <div className="flex items-start gap-4">
              <div
                className={`p-3.5 rounded-2xl shrink-0 mt-0.5 ${
                  item.completed ? 'bg-emerald-100' : 'bg-slate-100'
                }`}
              >
                {getCategoryIcon(item.category)}
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-teal-100 text-teal-800">
                    {item.time}
                  </span>
                  {item.category === 'medicine' && (
                    <span className="text-[11px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-rose-100 text-rose-800">
                      Medicine
                    </span>
                  )}
                </div>

                <h3
                  className={`text-xl sm:text-2xl font-black mt-1 ${
                    item.completed ? 'text-emerald-950 line-through opacity-80' : 'text-slate-900'
                  }`}
                >
                  {item.title}
                </h3>

                <p className="text-base text-slate-600 font-medium mt-1 leading-snug">
                  {item.description}
                </p>

                <div className="mt-3 flex items-center gap-3">
                  <button
                    onClick={(e) => speakItem(item, e)}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-teal-700 bg-teal-50 hover:bg-teal-100 px-3 py-1.5 rounded-xl border border-teal-200 transition"
                  >
                    <Volume2 className="w-4 h-4" />
                    <span>Hear Reminder</span>
                  </button>

                  <span className="text-xs font-semibold text-slate-500">
                    {item.completed ? t.medicineTaken : 'Tap to mark done'}
                  </span>
                </div>
              </div>
            </div>

            <div className="shrink-0 pt-1">
              {item.completed ? (
                <CheckCircle2 className="w-9 h-9 text-emerald-600 fill-emerald-100" />
              ) : (
                <Circle className="w-9 h-9 text-slate-300 hover:text-teal-500" />
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
