import React from 'react';
import { ArrowLeft, Phone, Volume2, Heart, MapPin, Sparkles } from 'lucide-react';
import { PatientProfile, FamilyMember } from '../../types';
import { speechService } from '../../services/speechService';
import { translations } from '../../utils/translations';

interface FamilyAlbumViewProps {
  patient: PatientProfile;
  onBack: () => void;
}

export const FamilyAlbumView: React.FC<FamilyAlbumViewProps> = ({ patient, onBack }) => {
  const t = translations[patient.language] || translations.en;

  const handleSpeakMember = (m: FamilyMember) => {
    speechService.speak(
      `${m.name}, your ${m.relation}. ${m.location}. ${m.keyMemory}`,
      patient.language
    );
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 animate-fadeIn">
      {/* Top Header */}
      <div className="flex items-center justify-between gap-3 mb-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 bg-white hover:bg-slate-100 px-4 py-2.5 rounded-2xl border-2 border-slate-200 text-slate-800 font-bold shadow-sm transition active:scale-95 text-base sm:text-lg"
        >
          <ArrowLeft className="w-6 h-6 text-teal-700" />
          <span>{t.home}</span>
        </button>

        <div className="inline-flex items-center gap-2 bg-rose-50 text-rose-800 px-4 py-2 rounded-2xl border border-rose-200 text-sm font-bold">
          <Heart className="w-4 h-4 fill-rose-500 text-rose-500" />
          <span>{patient.familyMembers.length} Loved Ones</span>
        </div>
      </div>

      {/* Album Title */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 mb-6 shadow-sm border-2 border-teal-100 text-center">
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900">
          {t.family}
        </h1>
        <p className="text-slate-600 font-medium text-base sm:text-lg mt-1 max-w-lg mx-auto">
          Tap on any family member’s picture to hear their voice note and remember cherished moments.
        </p>
      </div>

      {/* Family Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {patient.familyMembers.map((member) => (
          <div
            key={member.id}
            onClick={() => handleSpeakMember(member)}
            className="bg-white rounded-3xl p-6 shadow-sm border-3 border-teal-100 hover:border-teal-400 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start gap-4">
                <img
                  src={member.photoUrl}
                  alt={member.name}
                  className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl object-cover border-4 border-amber-200 shadow-sm shrink-0"
                />

                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-teal-700 bg-teal-50 px-2.5 py-0.5 rounded-full border border-teal-200">
                    {member.relation}
                  </span>

                  <h3 className="text-2xl font-black text-slate-900 mt-1">
                    {member.name}
                  </h3>

                  <div className="flex items-center gap-1.5 text-sm text-slate-600 mt-1 font-medium">
                    <MapPin className="w-4 h-4 text-teal-600 shrink-0" />
                    <span>{member.location}</span>
                  </div>
                </div>
              </div>

              {/* Cherished Memory Quote */}
              <div className="mt-4 p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200 text-slate-800 text-sm font-medium italic">
                "{member.keyMemory}"
              </div>
            </div>

            {/* Action Bar */}
            <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleSpeakMember(member);
                }}
                className="flex items-center gap-1.5 bg-teal-50 hover:bg-teal-100 text-teal-800 px-3.5 py-2 rounded-xl text-sm font-bold border border-teal-200 transition"
              >
                <Volume2 className="w-4 h-4 text-teal-700" />
                <span>Hear About {member.name.split(' ')[0]}</span>
              </button>

              <a
                href={`tel:${member.phone}`}
                onClick={(e) => e.stopPropagation()}
                className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-2 rounded-xl text-sm font-bold shadow-xs transition active:scale-95"
              >
                <Phone className="w-4 h-4" />
                <span>Call</span>
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
