import React from 'react';
import { 
  Gamepad2, 
  Calendar, 
  Image as ImageIcon, 
  ShieldAlert, 
  Sparkles, 
  Heart, 
  Volume2, 
  ChevronRight,
  Smile
} from 'lucide-react';
import { PatientProfile, GameType } from '../../types';
import { translations } from '../../utils/translations';
import { speechService } from '../../services/speechService';

interface PatientHomeProps {
  patient: PatientProfile;
  onNavigateToGame: (gameType: GameType) => void;
  onNavigateToRoutine: () => void;
  onNavigateToFamily: () => void;
  onTriggerSOS: () => void;
}

export const PatientHome: React.FC<PatientHomeProps> = ({
  patient,
  onNavigateToGame,
  onNavigateToRoutine,
  onNavigateToFamily,
  onTriggerSOS,
}) => {
  const t = translations[patient.language] || translations.en;

  const handleSpeakWelcome = () => {
    speechService.speak(
      `Hello ${patient.nickname}! Welcome to your MindMate home in ${patient.location}. Tap the big buttons to play games, check your day, or see your family.`,
      patient.language
    );
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 animate-fadeIn">
      {/* Warm Greeting Header */}
      <div className="bg-gradient-to-br from-teal-800 to-teal-900 text-white rounded-3xl p-6 sm:p-8 mb-6 shadow-md border-3 border-teal-700 relative overflow-hidden">
        {/* Subtle decorative motif */}
        <div className="absolute top-2 right-4 text-7xl opacity-15 select-none pointer-events-none">
          🌺
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400 text-slate-900 text-xs font-black uppercase tracking-wider mb-2">
              <Smile className="w-4 h-4" />
              <span>Good Day</span>
            </span>

            <h1 className="text-3xl sm:text-4xl font-black tracking-tight">
              {t.goodMorning}, {patient.nickname}!
            </h1>

            <p className="text-teal-100 text-base sm:text-lg font-medium mt-1">
              {t.encouragingFeedback}
            </p>
          </div>

          <button
            onClick={handleSpeakWelcome}
            className="flex items-center gap-2 bg-white/20 hover:bg-white/30 text-white px-4 py-2.5 rounded-2xl font-bold text-sm sm:text-base transition active:scale-95 border border-white/30 shrink-0 self-start sm:self-auto"
          >
            <Volume2 className="w-5 h-5 text-amber-300" />
            <span>Read to Me</span>
          </button>
        </div>
      </div>

      {/* Main 4 Primary Action Cards with Huge Tap Targets & High Contrast */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 mb-8">
        
        {/* Card 1: Play Cognitive Games */}
        <button
          onClick={() => onNavigateToGame('memory_match')}
          className="group p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-900 shadow-md transition-all duration-200 transform active:scale-97 text-left border-4 border-amber-300 flex flex-col justify-between min-h-[180px]"
        >
          <div className="flex items-start justify-between">
            <div className="p-4 rounded-2xl bg-slate-950/15 text-slate-900">
              <Gamepad2 className="w-10 h-10 stroke-[2.5]" />
            </div>
            <span className="text-3xl">🦏</span>
          </div>

          <div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
              {t.playGame}
            </h2>
            <p className="text-slate-900/80 font-bold text-base mt-1">
              5 gentle memory & regional music games
            </p>
          </div>
        </button>

        {/* Card 2: My Day & Medicine */}
        <button
          onClick={onNavigateToRoutine}
          className="group p-6 sm:p-8 rounded-3xl bg-white hover:bg-teal-50/50 text-slate-900 shadow-md transition-all duration-200 transform active:scale-97 text-left border-4 border-teal-200 flex flex-col justify-between min-h-[180px]"
        >
          <div className="flex items-start justify-between">
            <div className="p-4 rounded-2xl bg-teal-100 text-teal-800">
              <Calendar className="w-10 h-10 stroke-[2.5]" />
            </div>
            <span className="text-3xl">🍵</span>
          </div>

          <div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              {t.myDay}
            </h2>
            <p className="text-slate-600 font-bold text-base mt-1">
              Assam tea, medicines & daily routine
            </p>
          </div>
        </button>

        {/* Card 3: Family Album */}
        <button
          onClick={onNavigateToFamily}
          className="group p-6 sm:p-8 rounded-3xl bg-white hover:bg-rose-50/50 text-slate-900 shadow-md transition-all duration-200 transform active:scale-97 text-left border-4 border-rose-200 flex flex-col justify-between min-h-[180px]"
        >
          <div className="flex items-start justify-between">
            <div className="p-4 rounded-2xl bg-rose-100 text-rose-700">
              <ImageIcon className="w-10 h-10 stroke-[2.5]" />
            </div>
            <span className="text-3xl">❤️</span>
          </div>

          <div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              {t.family}
            </h2>
            <p className="text-slate-600 font-bold text-base mt-1">
              {patient.familyMembers.length} loved ones & photos
            </p>
          </div>
        </button>

        {/* Card 4: Need Help (SOS) */}
        <button
          onClick={onTriggerSOS}
          className="group p-6 sm:p-8 rounded-3xl bg-rose-600 hover:bg-rose-700 text-white shadow-md transition-all duration-200 transform active:scale-97 text-left border-4 border-rose-400 flex flex-col justify-between min-h-[180px]"
        >
          <div className="flex items-start justify-between">
            <div className="p-4 rounded-2xl bg-rose-800/60 text-white">
              <ShieldAlert className="w-10 h-10 stroke-[2.5]" />
            </div>
            <span className="text-xs font-black uppercase tracking-wider bg-rose-800 px-3 py-1 rounded-full animate-pulse">
              1-Tap Alert
            </span>
          </div>

          <div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
              {t.help}
            </h2>
            <p className="text-rose-100 font-bold text-base mt-1">
              Notify {patient.caregiver.name} immediately
            </p>
          </div>
        </button>
      </div>

      {/* Quick Access to the 5 Regional Games */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border-2 border-teal-100">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-amber-500" />
            <h3 className="text-xl sm:text-2xl font-black text-slate-900">
              Choose a Gentle Game
            </h3>
          </div>
          <span className="text-xs font-bold text-teal-700 bg-teal-50 px-3 py-1 rounded-full border border-teal-200">
            Regional NER Themes
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          <button
            onClick={() => onNavigateToGame('memory_match')}
            className="p-4 rounded-2xl border-2 border-slate-200 hover:border-teal-500 hover:bg-teal-50/50 text-left transition flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <span className="text-3xl">🦏</span>
              <div>
                <p className="font-extrabold text-slate-900">{t.memoryGame}</p>
                <p className="text-xs text-slate-500">Match cards</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>

          <button
            onClick={() => onNavigateToGame('name_object')}
            className="p-4 rounded-2xl border-2 border-slate-200 hover:border-teal-500 hover:bg-teal-50/50 text-left transition flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <span className="text-3xl">👒</span>
              <div>
                <p className="font-extrabold text-slate-900">{t.nameObjectGame}</p>
                <p className="text-xs text-slate-500">Identify pictures</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>

          <button
            onClick={() => onNavigateToGame('sequence_recall')}
            className="p-4 rounded-2xl border-2 border-slate-200 hover:border-teal-500 hover:bg-teal-50/50 text-left transition flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <span className="text-3xl">🥁</span>
              <div>
                <p className="font-extrabold text-slate-900">{t.sequenceGame}</p>
                <p className="text-xs text-slate-500">Dhol rhythm order</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>

          <button
            onClick={() => onNavigateToGame('orientation_quiz')}
            className="p-4 rounded-2xl border-2 border-slate-200 hover:border-teal-500 hover:bg-teal-50/50 text-left transition flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <span className="text-3xl">☀️</span>
              <div>
                <p className="font-extrabold text-slate-900">{t.orientationGame}</p>
                <p className="text-xs text-slate-500">Day & time questions</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>

          <button
            onClick={() => onNavigateToGame('folk_music')}
            className="p-4 rounded-2xl border-2 border-slate-200 hover:border-teal-500 hover:bg-teal-50/50 text-left transition flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <span className="text-3xl">🎋</span>
              <div>
                <p className="font-extrabold text-slate-900">{t.musicGame}</p>
                <p className="text-xs text-slate-500">Instrument audio recall</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>
        </div>
      </div>
    </div>
  );
};
