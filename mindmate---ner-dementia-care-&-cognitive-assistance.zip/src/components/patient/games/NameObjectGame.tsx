import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { ArrowLeft, Volume2, Award, CheckCircle2, HeartHandshake, Sparkles } from 'lucide-react';
import { PatientProfile } from '../../../types';
import { soundService } from '../../../services/soundService';
import { speechService } from '../../../services/speechService';
import { StorageService } from '../../../services/storage';
import { CognitiveEngine } from '../../../services/cognitiveEngine';
import { translations } from '../../../utils/translations';

interface NameObjectGameProps {
  patient: PatientProfile;
  onBack: () => void;
  initialLevel?: number;
}

interface QuizItem {
  id: string;
  imageIcon: string;
  title: string;
  regionalTitle: string;
  category: string;
  hint: string;
  options: { text: string; regionalText: string; isCorrect: boolean }[];
}

const OBJECTS: QuizItem[] = [
  {
    id: 'q1',
    imageIcon: '👒',
    title: 'Bihu Japi',
    regionalTitle: 'বিহু জাপি',
    category: 'Cultural Headgear',
    hint: 'Made of tightly woven bamboo and tokou leaves, decorated with red fabric.',
    options: [
      { text: 'Bihu Japi (Bamboo Hat)', regionalText: 'বিহু জাপি', isCorrect: true },
      { text: 'Earthen Pitcher (Kalah)', regionalText: 'মাটিৰ কলহ', isCorrect: false },
      { text: 'Tea Basket (Khorahi)', regionalText: 'চাহ তুলিব খোৰাহী', isCorrect: false },
    ],
  },
  {
    id: 'q2',
    imageIcon: '🧣',
    title: 'Phulam Gamosa',
    regionalTitle: 'ফুলাম গামোচা',
    category: 'Traditional Handloom',
    hint: 'White cotton towel with vibrant red woven floral motifs at the ends.',
    options: [
      { text: 'Silk Chadar', regionalText: 'পাটৰ চাদৰ', isCorrect: false },
      { text: 'Phulam Gamosa', regionalText: 'ফুলাম গামোচা', isCorrect: true },
      { text: 'Mizo Puan', regionalText: 'পুৱান কাপোৰ', isCorrect: false },
    ],
  },
  {
    id: 'q3',
    imageIcon: '🦏',
    title: 'One-Horned Rhino',
    regionalTitle: 'এশিঙীয়া গঁড়',
    category: 'Wildlife Pride of Kaziranga',
    hint: 'Great majestic beast that grazes in the tall elephant grass of Kaziranga.',
    options: [
      { text: 'One-Horned Rhino', regionalText: 'এশিঙীয়া গঁড়', isCorrect: true },
      { text: 'Wild Water Buffalo', regionalText: 'বনৰীয়া ম’হ', isCorrect: false },
      { text: 'Sangai Deer', regionalText: 'ছাংগাই পহু', isCorrect: false },
    ],
  },
  {
    id: 'q4',
    imageIcon: '🍵',
    title: 'Fresh Assam Lal Cha',
    regionalTitle: 'ৰঙা চাহ',
    category: 'Daily Beverage',
    hint: 'Steaming red brew from tea gardens, enjoyed morning and evening.',
    options: [
      { text: 'Rice Beer (Apong)', regionalText: 'সাঁজ পানী', isCorrect: false },
      { text: 'Fresh Red Tea (Lal Cha)', regionalText: 'ৰঙা চাহ', isCorrect: true },
      { text: 'Sugarcane Juice', regionalText: 'কুঁহিয়াৰৰ ৰস', isCorrect: false },
    ],
  },
  {
    id: 'q5',
    imageIcon: '🥁',
    title: 'Bihu Dhol',
    regionalTitle: 'বিহু ঢোল',
    category: 'Folk Musical Instrument',
    hint: 'Double-sided wooden drum played during the harvest springtime festival.',
    options: [
      { text: 'Bihu Dhol', regionalText: 'বিহু ঢোল', isCorrect: true },
      { text: 'Bamboo Flute', regionalText: 'বাঁহী', isCorrect: false },
      { text: 'Gogona Harp', regionalText: 'গগণা', isCorrect: false },
    ],
  },
];

export const NameObjectGame: React.FC<NameObjectGameProps> = ({ patient, onBack, initialLevel = 1 }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [scoreCount, setScoreCount] = useState(0);
  const [errorsCount, setErrorsCount] = useState(0);
  const [feedback, setFeedback] = useState<string>('');
  const [isDone, setIsDone] = useState(false);
  const [startTime] = useState<number>(Date.now());
  const [sessionScore, setSessionScore] = useState(0);

  const t = translations[patient.language] || translations.en;
  const currentItem = OBJECTS[currentIndex];

  const handleSpeakQuestion = () => {
    speechService.speak(
      `What is this picture? ${currentItem.regionalTitle}. ${currentItem.hint}`,
      patient.language
    );
  };

  const handleSelectOption = (index: number) => {
    if (selectedOption !== null) return; // already answered
    setSelectedOption(index);
    const chosen = currentItem.options[index];

    if (chosen.isCorrect) {
      soundService.playSuccess();
      setScoreCount((s) => s + 1);
      setFeedback('Wonderful! Exactly right.');
      speechService.speak(`${t.greatJob}! That is ${chosen.regionalText}.`, patient.language);
    } else {
      soundService.playGentleHint();
      setErrorsCount((e) => e + 1);
      const correctOne = currentItem.options.find((o) => o.isCorrect);
      setFeedback(`Good try! It is ${correctOne?.regionalText}. Let’s remember together.`);
      speechService.speak(`Good effort! That is ${correctOne?.regionalText}.`, patient.language);
    }

    // Move to next after brief pause
    setTimeout(() => {
      if (currentIndex + 1 < OBJECTS.length) {
        setCurrentIndex((prev) => prev + 1);
        setSelectedOption(null);
        setFeedback('');
      } else {
        handleFinishGame();
      }
    }, 2200);
  };

  const handleFinishGame = () => {
    setIsDone(true);
    const elapsedMs = Date.now() - startTime;
    const accuracy = Math.round((scoreCount / OBJECTS.length) * 100);

    const calculatedScore = CognitiveEngine.calculateSessionScore(
      'name_object',
      initialLevel,
      accuracy,
      elapsedMs,
      errorsCount
    );

    setSessionScore(calculatedScore);

    StorageService.addGameSession({
      id: `session-name-${Date.now()}`,
      patientId: patient.id,
      gameType: 'name_object',
      level: initialLevel,
      accuracy,
      reactionTimeMs: Math.round(elapsedMs / OBJECTS.length),
      errors: errorsCount,
      completed: true,
      timestamp: new Date().toISOString(),
      score: calculatedScore,
    });

    confetti({ particleCount: 50, spread: 70 });
    speechService.speak(`${t.wellDone}! You recognized the pictures so well.`, patient.language);
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setSelectedOption(null);
    setScoreCount(0);
    setErrorsCount(0);
    setFeedback('');
    setIsDone(false);
  };

  return (
    <div className="max-w-2xl mx-auto p-4 sm:p-6 animate-fadeIn">
      {/* Navigation Header */}
      <div className="flex items-center justify-between gap-3 mb-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 bg-white hover:bg-slate-100 px-4 py-2.5 rounded-2xl border-2 border-slate-200 text-slate-800 font-bold shadow-sm transition active:scale-95 text-base sm:text-lg"
        >
          <ArrowLeft className="w-6 h-6 text-teal-700" />
          <span>{t.home}</span>
        </button>

        <div className="flex items-center gap-2 bg-teal-50 px-3.5 py-1.5 rounded-xl border border-teal-200">
          <span className="text-xs font-bold text-teal-700 uppercase">Item</span>
          <span className="text-lg font-black text-teal-900">
            {currentIndex + 1} / {OBJECTS.length}
          </span>
        </div>
      </div>

      {!isDone ? (
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border-2 border-teal-100 text-center">
          <span className="text-xs font-bold uppercase tracking-wider text-teal-700 bg-teal-50 px-3 py-1 rounded-full border border-teal-200">
            {currentItem.category}
          </span>

          {/* Big High-Contrast Illustration */}
          <div className="my-6 mx-auto w-40 h-40 sm:w-48 sm:h-48 rounded-3xl bg-amber-50 border-4 border-amber-200 flex items-center justify-center text-7xl sm:text-8xl shadow-inner">
            {currentItem.imageIcon}
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mb-2">
            What is this picture?
          </h2>

          <p className="text-slate-600 font-medium text-base sm:text-lg max-w-md mx-auto mb-4">
            {currentItem.hint}
          </p>

          <button
            onClick={handleSpeakQuestion}
            className="inline-flex items-center gap-2 bg-teal-50 hover:bg-teal-100 border border-teal-200 text-teal-800 px-4 py-2 rounded-xl text-sm font-bold mb-6 transition"
          >
            <Volume2 className="w-4 h-4 text-teal-700" />
            <span>Hear Clue Aloud</span>
          </button>

          {/* Large Choice Buttons (Accessible for Elderly) */}
          <div className="space-y-3.5">
            {currentItem.options.map((opt, idx) => {
              const isSelected = selectedOption === idx;
              let btnStyle = 'bg-white border-2 border-slate-300 text-slate-800 hover:border-teal-500 hover:bg-teal-50/50';

              if (selectedOption !== null) {
                if (opt.isCorrect) {
                  btnStyle = 'bg-emerald-100 border-4 border-emerald-500 text-emerald-950 scale-102';
                } else if (isSelected && !opt.isCorrect) {
                  btnStyle = 'bg-amber-100 border-2 border-amber-400 text-amber-950 opacity-90';
                } else {
                  btnStyle = 'bg-slate-50 border border-slate-200 text-slate-400 opacity-60';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(idx)}
                  disabled={selectedOption !== null}
                  className={`w-full py-4 px-6 rounded-2xl font-black text-lg sm:text-xl text-left transition flex items-center justify-between shadow-xs ${btnStyle}`}
                >
                  <div className="flex flex-col">
                    <span className="text-slate-900 font-extrabold">{opt.regionalText}</span>
                    <span className="text-sm font-medium text-slate-600">{opt.text}</span>
                  </div>

                  {selectedOption !== null && opt.isCorrect && (
                    <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {feedback && (
            <div className="mt-5 p-3 rounded-2xl bg-teal-50 text-teal-900 font-bold text-base animate-fadeIn border border-teal-200">
              {feedback}
            </div>
          )}
        </div>
      ) : (
        /* Completion View */
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border-2 border-teal-100 text-center animate-fadeIn">
          <div className="w-16 h-16 rounded-full bg-amber-400 text-slate-900 flex items-center justify-center mx-auto mb-4 shadow-md">
            <Award className="w-9 h-9" />
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
            {t.greatJob}!
          </h2>
          <p className="text-base sm:text-lg text-slate-600 font-medium mt-1">
            You recognized {scoreCount} out of {OBJECTS.length} cultural pictures!
          </p>

          <div className="my-6 inline-flex items-center gap-6 bg-teal-50 px-6 py-3 rounded-2xl border border-teal-200">
            <div>
              <span className="text-xs font-bold text-teal-700 uppercase">Cognitive Score</span>
              <p className="text-3xl font-black text-teal-900">{sessionScore} / 100</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={handleRestart}
              className="bg-teal-700 hover:bg-teal-800 text-white px-6 py-3.5 rounded-2xl font-bold text-lg shadow-md transition"
            >
              Play Again
            </button>
            <button
              onClick={onBack}
              className="bg-amber-400 hover:bg-amber-500 text-slate-900 px-6 py-3.5 rounded-2xl font-bold text-lg shadow-sm transition"
            >
              Back to Home
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
