import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { ArrowLeft, Volume2, Award, Play, CheckCircle2, Music } from 'lucide-react';
import { PatientProfile } from '../../../types';
import { soundService } from '../../../services/soundService';
import { speechService } from '../../../services/speechService';
import { StorageService } from '../../../services/storage';
import { CognitiveEngine } from '../../../services/cognitiveEngine';
import { translations } from '../../../utils/translations';

interface FolkMusicGameProps {
  patient: PatientProfile;
  onBack: () => void;
  initialLevel?: number;
}

interface AudioQuizItem {
  id: string;
  instrumentType: 'dhol' | 'pepa' | 'tokari' | 'flute' | 'gong';
  title: string;
  regionalTitle: string;
  description: string;
  options: {
    name: string;
    regionalName: string;
    icon: string;
    type: 'dhol' | 'pepa' | 'tokari' | 'flute' | 'gong';
  }[];
}

const AUDIO_QUESTIONS: AudioQuizItem[] = [
  {
    id: 'm1',
    instrumentType: 'dhol',
    title: 'Bihu Dhol Beat',
    regionalTitle: 'বিহু ঢোলৰ মাত',
    description: 'Listen to the rhythmic heartbeat drum of springtime festivals in Assam.',
    options: [
      { name: 'Bihu Dhol (Drum)', regionalName: 'বিহু ঢোল', icon: '🥁', type: 'dhol' },
      { name: 'Bamboo Flute', regionalName: 'বাঁহী', icon: '🎋', type: 'flute' },
      { name: 'Bronze Gong', regionalName: 'কাঁহৰ ঘণ্টা', icon: '🔔', type: 'gong' },
    ],
  },
  {
    id: 'm2',
    instrumentType: 'pepa',
    title: 'Buffalo Horn Pepa',
    regionalTitle: 'ম’হৰ শিঙৰ পেঁপা',
    description: 'Listen to the sharp, piercing reed call echoing across the Brahmaputra fields.',
    options: [
      { name: 'Tokari Lute', regionalName: 'টোকাৰী', icon: '🪕', type: 'tokari' },
      { name: 'Buffalo Horn Pepa', regionalName: 'পেঁপা', icon: '🎺', type: 'pepa' },
      { name: 'Bihu Dhol', regionalName: 'বিহু ঢোল', icon: '🥁', type: 'dhol' },
    ],
  },
  {
    id: 'm3',
    instrumentType: 'flute',
    title: 'Mizo Mountain Bamboo Flute',
    regionalTitle: 'পাহাৰীয়া বাঁহী',
    description: 'Listen to the sweet breath of the bamboo reed whispering across misty hills.',
    options: [
      { name: 'Mountain Flute', regionalName: 'বাঁহী', icon: '🎋', type: 'flute' },
      { name: 'Bronze Temple Gong', regionalName: 'ঘণ্টা', icon: '🔔', type: 'gong' },
      { name: 'Tokari Lute', regionalName: 'টোকাৰী', icon: '🪕', type: 'tokari' },
    ],
  },
  {
    id: 'm4',
    instrumentType: 'tokari',
    title: 'Folk Tokari String Pluck',
    regionalTitle: 'টোকাৰীৰ সুৰ',
    description: 'Listen to the contemplative single-string pluck of wandering baul and dehbichar singers.',
    options: [
      { name: 'Bihu Dhol', regionalName: 'বিহু ঢোল', icon: '🥁', type: 'dhol' },
      { name: 'Tokari Lute', regionalName: 'টোকাৰী', icon: '🪕', type: 'tokari' },
      { name: 'Pepa Horn', regionalName: 'পেঁপা', icon: '🎺', type: 'pepa' },
    ],
  },
];

export const FolkMusicGame: React.FC<FolkMusicGameProps> = ({ patient, onBack, initialLevel = 1 }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [scoreCount, setScoreCount] = useState(0);
  const [errors, setErrors] = useState(0);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [isCompleted, setIsCompleted] = useState(false);
  const [sessionScore, setSessionScore] = useState(0);

  const t = translations[patient.language] || translations.en;
  const currentItem = AUDIO_QUESTIONS[currentIndex];

  const playInstrumentSound = () => {
    setIsPlayingAudio(true);
    soundService.playInstrument(currentItem.instrumentType);
    setTimeout(() => {
      soundService.playInstrument(currentItem.instrumentType);
    }, 450);
    setTimeout(() => {
      setIsPlayingAudio(false);
    }, 900);
  };

  const handleSelect = (type: string) => {
    if (selectedType !== null) return;
    setSelectedType(type);

    if (type === currentItem.instrumentType) {
      soundService.playSuccess();
      setScoreCount((s) => s + 1);
      setFeedback('Wonderful! That is exactly the right sound.');
      speechService.speak(`${t.greatJob}! You recognized the folk instrument.`, patient.language);
    } else {
      soundService.playGentleHint();
      setErrors((e) => e + 1);
      const correct = currentItem.options.find((o) => o.type === currentItem.instrumentType);
      setFeedback(`Good try! That sound belongs to ${correct?.regionalName}.`);
      speechService.speak(`Good try. It was the ${correct?.regionalName}.`, patient.language);
    }

    setTimeout(() => {
      if (currentIndex + 1 < AUDIO_QUESTIONS.length) {
        setCurrentIndex((i) => i + 1);
        setSelectedType(null);
        setFeedback('');
      } else {
        handleFinish();
      }
    }, 2400);
  };

  const handleFinish = () => {
    setIsCompleted(true);
    const accuracy = Math.round((scoreCount / AUDIO_QUESTIONS.length) * 100);
    const calculatedScore = CognitiveEngine.calculateSessionScore('folk_music', initialLevel, accuracy, 2200, errors);
    setSessionScore(calculatedScore);

    StorageService.addGameSession({
      id: `session-music-${Date.now()}`,
      patientId: patient.id,
      gameType: 'folk_music',
      level: initialLevel,
      accuracy,
      reactionTimeMs: 2200,
      errors,
      completed: true,
      timestamp: new Date().toISOString(),
      score: calculatedScore,
    });

    confetti({ particleCount: 50, spread: 60 });
    speechService.speak(`${t.wellDone}! North East folk music stimulates memories beautifully.`, patient.language);
  };

  return (
    <div className="max-w-2xl mx-auto p-4 sm:p-6 animate-fadeIn">
      <div className="flex items-center justify-between gap-3 mb-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 bg-white hover:bg-slate-100 px-4 py-2.5 rounded-2xl border-2 border-slate-200 text-slate-800 font-bold shadow-sm transition active:scale-95 text-base sm:text-lg"
        >
          <ArrowLeft className="w-6 h-6 text-teal-700" />
          <span>{t.home}</span>
        </button>

        <div className="flex items-center gap-2 bg-teal-50 px-3.5 py-1.5 rounded-xl border border-teal-200">
          <span className="text-xs font-bold text-teal-700 uppercase">Melody</span>
          <span className="text-lg font-black text-teal-900">{currentIndex + 1} / {AUDIO_QUESTIONS.length}</span>
        </div>
      </div>

      {!isCompleted ? (
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border-2 border-teal-100 text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Music className="w-6 h-6 text-amber-500" />
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
              {t.musicGame}
            </h2>
          </div>

          <p className="text-slate-600 font-medium text-base sm:text-lg mb-6">
            Tap the button below to listen to the sound, then choose which instrument made it.
          </p>

          {/* Big Audio Play Button */}
          <button
            onClick={playInstrumentSound}
            className={`w-32 h-32 rounded-full mx-auto my-4 flex flex-col items-center justify-center shadow-lg transition-all transform active:scale-95 border-4 ${
              isPlayingAudio
                ? 'bg-amber-500 border-amber-300 scale-110 text-white animate-pulse'
                : 'bg-teal-700 border-teal-500 hover:bg-teal-800 text-white'
            }`}
          >
            <Play className={`w-12 h-12 fill-current ${isPlayingAudio ? 'animate-spin' : ''}`} />
            <span className="text-xs font-black uppercase tracking-wider mt-1">
              {isPlayingAudio ? 'Playing...' : 'Play Sound'}
            </span>
          </button>

          <p className="text-sm font-semibold text-teal-900 mb-8">
            {currentItem.description}
          </p>

          {/* Choice Cards */}
          <div className="space-y-3.5">
            {currentItem.options.map((opt) => {
              const isSelected = selectedType === opt.type;
              const isCorrect = opt.type === currentItem.instrumentType;
              let style = 'bg-white border-2 border-slate-300 hover:border-teal-500 hover:bg-teal-50/50';

              if (selectedType !== null) {
                if (isCorrect) {
                  style = 'bg-emerald-100 border-4 border-emerald-500 text-emerald-950 scale-102';
                } else if (isSelected && !isCorrect) {
                  style = 'bg-amber-100 border-2 border-amber-400 text-amber-950 opacity-90';
                } else {
                  style = 'bg-slate-50 border border-slate-200 text-slate-400 opacity-60';
                }
              }

              return (
                <button
                  key={opt.type}
                  onClick={() => handleSelect(opt.type)}
                  disabled={selectedType !== null}
                  className={`w-full py-4 px-6 rounded-2xl font-bold text-lg sm:text-xl text-left transition flex items-center justify-between shadow-xs ${style}`}
                >
                  <div className="flex items-center gap-4">
                    <span className="text-4xl">{opt.icon}</span>
                    <div className="flex flex-col">
                      <span className="font-extrabold text-slate-900">{opt.regionalName}</span>
                      <span className="text-sm font-medium text-slate-600">{opt.name}</span>
                    </div>
                  </div>
                  {selectedType !== null && isCorrect && (
                    <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {feedback && (
            <div className="mt-5 p-3 rounded-2xl bg-teal-50 text-teal-900 font-bold text-base animate-fadeIn border border-teal-200">
              {feedback}
            </div>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border-2 border-teal-100 text-center animate-fadeIn">
          <div className="w-16 h-16 rounded-full bg-emerald-500 text-white flex items-center justify-center mx-auto mb-4 shadow-md">
            <Award className="w-9 h-9" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
            {t.wellDone}!
          </h2>
          <p className="text-base sm:text-lg text-slate-600 font-medium mt-1">
            Folk rhythm recall strengthens associative auditory memory in dementia care.
          </p>
          <div className="my-6 inline-flex items-center gap-6 bg-teal-50 px-6 py-3 rounded-2xl border border-teal-200">
            <div>
              <span className="text-xs font-bold text-teal-700 uppercase">Score</span>
              <p className="text-3xl font-black text-teal-900">{sessionScore} / 100</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => {
                setCurrentIndex(0);
                setSelectedType(null);
                setScoreCount(0);
                setErrors(0);
                setIsCompleted(false);
              }}
              className="bg-teal-700 hover:bg-teal-800 text-white px-6 py-3.5 rounded-2xl font-bold text-lg shadow-md transition"
            >
              Play Again
            </button>
            <button
              onClick={onBack}
              className="bg-amber-400 hover:bg-amber-500 text-slate-900 px-6 py-3.5 rounded-2xl font-bold text-lg shadow-sm transition"
            >
              Back to Home
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
