import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { ArrowLeft, Play, RotateCcw, Volume2, Award, Sparkles } from 'lucide-react';
import { PatientProfile } from '../../../types';
import { soundService } from '../../../services/soundService';
import { speechService } from '../../../services/speechService';
import { StorageService } from '../../../services/storage';
import { CognitiveEngine } from '../../../services/cognitiveEngine';
import { translations } from '../../../utils/translations';

interface SequenceRecallGameProps {
  patient: PatientProfile;
  onBack: () => void;
  initialLevel?: number;
}

interface PadItem {
  id: 'dhol' | 'pepa' | 'tokari' | 'flute';
  name: string;
  regionalName: string;
  icon: string;
  colorClass: string;
  activeColorClass: string;
}

const PADS: PadItem[] = [
  {
    id: 'dhol',
    name: 'Bihu Dhol',
    regionalName: 'বিহু ঢোল',
    icon: '🥁',
    colorClass: 'bg-amber-100 border-amber-300 text-amber-900',
    activeColorClass: 'bg-amber-400 border-amber-600 scale-105 ring-4 ring-amber-300',
  },
  {
    id: 'pepa',
    name: 'Buffalo Horn (Pepa)',
    regionalName: 'ম’হৰ শিঙৰ পেঁপা',
    icon: '🎺',
    colorClass: 'bg-rose-100 border-rose-300 text-rose-900',
    activeColorClass: 'bg-rose-400 border-rose-600 scale-105 ring-4 ring-rose-300',
  },
  {
    id: 'tokari',
    name: 'Tokari Lute',
    regionalName: 'টোকাৰী',
    icon: '🪕',
    colorClass: 'bg-emerald-100 border-emerald-300 text-emerald-900',
    activeColorClass: 'bg-emerald-400 border-emerald-600 scale-105 ring-4 ring-emerald-300',
  },
  {
    id: 'flute',
    name: 'Bamboo Flute',
    regionalName: 'বাঁহী',
    icon: '🎋',
    colorClass: 'bg-teal-100 border-teal-300 text-teal-900',
    activeColorClass: 'bg-teal-400 border-teal-600 scale-105 ring-4 ring-teal-300',
  },
];

export const SequenceRecallGame: React.FC<SequenceRecallGameProps> = ({ patient, onBack, initialLevel = 2 }) => {
  const [level, setLevel] = useState<number>(initialLevel);
  const [sequence, setSequence] = useState<('dhol' | 'pepa' | 'tokari' | 'flute')[]>([]);
  const [playerInput, setPlayerInput] = useState<('dhol' | 'pepa' | 'tokari' | 'flute')[]>([]);
  const [isPlayingSequence, setIsPlayingSequence] = useState(false);
  const [activePad, setActivePad] = useState<string | null>(null);
  const [errors, setErrors] = useState(0);
  const [roundCompleted, setRoundCompleted] = useState(false);
  const [sessionScore, setSessionScore] = useState(0);
  const [message, setMessage] = useState('Watch and listen to the instruments in order.');

  const t = translations[patient.language] || translations.en;

  // Generate sequence according to level:
  // Level 1: 2 items
  // Level 2: 3 items
  // Level 3: 4 items
  // Level 4: 5 items
  // Level 5: 6 items
  const startNewSequence = (lvl: number) => {
    const length = Math.min(6, lvl + 1);
    const pool: ('dhol' | 'pepa' | 'tokari' | 'flute')[] = ['dhol', 'pepa', 'tokari', 'flute'];
    const newSeq: ('dhol' | 'pepa' | 'tokari' | 'flute')[] = [];

    for (let i = 0; i < length; i++) {
      const pick = pool[Math.floor(Math.random() * pool.length)];
      newSeq.push(pick);
    }

    setSequence(newSeq);
    setPlayerInput([]);
    setRoundCompleted(false);
    playDemoSequence(newSeq);
  };

  useEffect(() => {
    startNewSequence(level);
  }, [level]);

  const playDemoSequence = async (seq: ('dhol' | 'pepa' | 'tokari' | 'flute')[]) => {
    setIsPlayingSequence(true);
    setMessage('Listen closely to the sequence...');
    await new Promise((r) => setTimeout(r, 600));

    for (let i = 0; i < seq.length; i++) {
      const item = seq[i];
      setActivePad(item);
      soundService.playInstrument(item);
      await new Promise((r) => setTimeout(r, 750));
      setActivePad(null);
      await new Promise((r) => setTimeout(r, 250));
    }

    setIsPlayingSequence(false);
    setMessage('Your turn! Tap the instruments in the same order.');
    speechService.speak('Your turn now. Tap the same instruments.', patient.language);
  };

  const handlePadClick = (padId: 'dhol' | 'pepa' | 'tokari' | 'flute') => {
    if (isPlayingSequence || roundCompleted) return;

    soundService.playInstrument(padId);
    setActivePad(padId);
    setTimeout(() => setActivePad(null), 300);

    const nextIndex = playerInput.length;
    const expected = sequence[nextIndex];

    if (padId === expected) {
      // Correct step
      const updated = [...playerInput, padId];
      setPlayerInput(updated);

      if (updated.length === sequence.length) {
        // Sequence fully completed!
        handleSuccess();
      }
    } else {
      // Gentle encouragement
      setErrors((e) => e + 1);
      soundService.playGentleHint();
      setMessage('That was a good try! Let’s watch the melody once more.');
      speechService.speak('Let’s watch the rhythm once more together.', patient.language);

      setTimeout(() => {
        setPlayerInput([]);
        playDemoSequence(sequence);
      }, 1500);
    }
  };

  const handleSuccess = () => {
    setRoundCompleted(true);
    soundService.playSuccess();
    confetti({ particleCount: 50, spread: 70 });

    const accuracy = Math.max(50, Math.round((sequence.length / (sequence.length + errors)) * 100));
    const finalScore = CognitiveEngine.calculateSessionScore(
      'sequence_recall',
      level,
      accuracy,
      2500,
      errors
    );
    setSessionScore(finalScore);

    StorageService.addGameSession({
      id: `session-seq-${Date.now()}`,
      patientId: patient.id,
      gameType: 'sequence_recall',
      level,
      accuracy,
      reactionTimeMs: 2400,
      errors,
      completed: true,
      timestamp: new Date().toISOString(),
      score: finalScore,
    });

    speechService.speak(`${t.greatJob}! You remembered the folk sequence beautifully.`, patient.language);
  };

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 animate-fadeIn">
      {/* Navigation & Controls */}
      <div className="flex items-center justify-between gap-3 mb-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 bg-white hover:bg-slate-100 px-4 py-2.5 rounded-2xl border-2 border-slate-200 text-slate-800 font-bold shadow-sm transition active:scale-95 text-base sm:text-lg"
        >
          <ArrowLeft className="w-6 h-6 text-teal-700" />
          <span>{t.home}</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold text-slate-600 hidden sm:inline">{t.level}:</span>
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map((lvl) => (
              <button
                key={lvl}
                onClick={() => setLevel(lvl)}
                className={`w-9 h-9 rounded-xl font-extrabold text-sm transition ${
                  level === lvl
                    ? 'bg-teal-700 text-white shadow-md ring-2 ring-amber-400'
                    : 'bg-white text-slate-700 border border-slate-200 hover:bg-teal-50'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={() => playDemoSequence(sequence)}
          disabled={isPlayingSequence}
          className="p-2.5 rounded-2xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 transition"
          title="Replay sequence"
        >
          <RotateCcw className="w-5 h-5 text-teal-700" />
        </button>
      </div>

      {/* Game Header */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 mb-6 shadow-sm border-2 border-teal-100 text-center">
        <div className="flex items-center justify-center gap-2 mb-1">
          <span className="text-3xl">🥁</span>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900">
            {t.sequenceGame}
          </h1>
        </div>
        <p className="text-base sm:text-lg font-bold text-teal-800 mt-2">
          {message}
        </p>

        {/* Progress dots */}
        <div className="flex justify-center items-center gap-2 mt-4">
          {sequence.map((_, idx) => (
            <div
              key={idx}
              className={`h-4 rounded-full transition-all duration-300 ${
                idx < playerInput.length
                  ? 'w-8 bg-emerald-500'
                  : 'w-4 bg-slate-200'
              }`}
            />
          ))}
        </div>
      </div>

      {/* 4 Folk Instrument Pads - Large tap targets (min 48px, high contrast) */}
      <div className="grid grid-cols-2 gap-4 max-w-xl mx-auto">
        {PADS.map((pad) => {
          const isActive = activePad === pad.id;
          return (
            <button
              key={pad.id}
              onClick={() => handlePadClick(pad.id)}
              disabled={isPlayingSequence || roundCompleted}
              className={`h-40 sm:h-48 rounded-3xl p-4 flex flex-col items-center justify-center text-center border-4 transition-all duration-200 active:scale-95 shadow-md ${
                isActive ? pad.activeColorClass : pad.colorClass
              }`}
            >
              <span className="text-5xl sm:text-6xl mb-2 filter drop-shadow-sm">{pad.icon}</span>
              <span className="text-lg sm:text-xl font-extrabold">{pad.regionalName}</span>
              <span className="text-xs sm:text-sm font-semibold opacity-80">{pad.name}</span>
            </button>
          );
        })}
      </div>

      {/* Completion Banner */}
      {roundCompleted && (
        <div className="mt-8 bg-white border-4 border-emerald-300 rounded-3xl p-6 text-center animate-fadeIn shadow-lg max-w-xl mx-auto">
          <div className="w-16 h-16 rounded-full bg-emerald-500 text-white flex items-center justify-center mx-auto mb-3 shadow-md">
            <Award className="w-9 h-9" />
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
            {t.wellDone}!
          </h2>
          <p className="text-base sm:text-lg text-slate-600 font-medium mt-1">
            You completed the folk melody sequence!
          </p>

          <div className="my-5 inline-flex items-center gap-6 bg-teal-50 px-6 py-3 rounded-2xl border border-teal-200">
            <div>
              <span className="text-xs font-bold text-teal-700 uppercase">Score</span>
              <p className="text-3xl font-black text-teal-900">{sessionScore} / 100</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => {
                setLevel((l) => Math.min(5, l + 1));
                startNewSequence(Math.min(5, level + 1));
              }}
              className="bg-teal-700 hover:bg-teal-800 text-white px-6 py-3.5 rounded-2xl font-bold text-lg shadow-md transition"
            >
              Next Rhythm Level
            </button>
            <button
              onClick={onBack}
              className="bg-amber-400 hover:bg-amber-500 text-slate-900 px-6 py-3.5 rounded-2xl font-bold text-lg shadow-sm transition"
            >
              Back to Home
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
