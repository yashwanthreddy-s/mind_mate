import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { ArrowLeft, Volume2, Award, CheckCircle2, Clock, MapPin, Calendar, Heart } from 'lucide-react';
import { PatientProfile } from '../../../types';
import { soundService } from '../../../services/soundService';
import { speechService } from '../../../services/speechService';
import { StorageService } from '../../../services/storage';
import { CognitiveEngine } from '../../../services/cognitiveEngine';
import { translations } from '../../../utils/translations';

interface OrientationQuizGameProps {
  patient: PatientProfile;
  onBack: () => void;
  initialLevel?: number;
}

interface Question {
  id: string;
  type: 'time' | 'day' | 'place' | 'family';
  icon: string;
  questionText: string;
  regionalText: string;
  options: { text: string; regionalText: string; isCorrect: boolean }[];
}

export const OrientationQuizGame: React.FC<OrientationQuizGameProps> = ({ patient, onBack, initialLevel = 1 }) => {
  const t = translations[patient.language] || translations.en;

  // Dynamically tailor orientation questions to current time & patient's location/family
  const currentHour = new Date().getHours();
  const timeOfDay = currentHour < 12 ? 'Morning' : currentHour < 17 ? 'Afternoon' : 'Evening';
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const todayDayName = dayNames[new Date().getDay()];

  const questions: Question[] = [
    {
      id: 'o1',
      type: 'time',
      icon: '☀️',
      questionText: 'What part of the day is it right now?',
      regionalText: 'এতিয়া দিনটোৰ কি সময়?',
      options: [
        { text: 'Morning (Sun is rising, tea time)', regionalText: 'পুৱা (চাহ খোৱাৰ সময়)', isCorrect: timeOfDay === 'Morning' },
        { text: 'Afternoon (Sun overhead, lunchtime)', regionalText: 'দুপৰীয়া (ভাত খোৱাৰ সময়)', isCorrect: timeOfDay === 'Afternoon' },
        { text: 'Evening / Night (Stars out, resting)', regionalText: 'গধূলি / ৰাতি (জিৰণিৰ সময়)', isCorrect: timeOfDay === 'Evening' },
      ],
    },
    {
      id: 'o2',
      type: 'day',
      icon: '📅',
      questionText: 'What day of the week is today?',
      regionalText: 'আজি বাৰ কি বাৰ?',
      options: [
        { text: todayDayName, regionalText: `আজি ${todayDayName}`, isCorrect: true },
        { text: dayNames[(new Date().getDay() + 2) % 7], regionalText: `${dayNames[(new Date().getDay() + 2) % 7]}`, isCorrect: false },
        { text: dayNames[(new Date().getDay() + 4) % 7], regionalText: `${dayNames[(new Date().getDay() + 4) % 7]}`, isCorrect: false },
      ],
    },
    {
      id: 'o3',
      type: 'place',
      icon: '🏡',
      questionText: 'Where is your home town located?',
      regionalText: 'আপোনাৰ ঘৰ কোনখন চহৰত?',
      options: [
        { text: `${patient.location} (${patient.state})`, regionalText: `${patient.location}`, isCorrect: true },
        { text: 'New Delhi (Capital)', regionalText: 'নতুন দিল্লী', isCorrect: false },
        { text: 'Mumbai (Maharashtra)', regionalText: 'মুম্বাই', isCorrect: false },
      ],
    },
    {
      id: 'o4',
      type: 'family',
      icon: '❤️',
      questionText: `Who is your son / caregiver who checks in on you?`,
      regionalText: `আপোনাৰ যত্ন লোৱা ল’ৰা/পৰিয়ালৰ সদস্যজন কোন?`,
      options: [
        { text: `${patient.caregiver.name} (${patient.caregiver.relation})`, regionalText: `${patient.caregiver.name}`, isCorrect: true },
        { text: 'Ramesh Sharma (Neighbor)', regionalText: 'ৰমেশ শৰ্মা', isCorrect: false },
        { text: 'Anil Das (Postman)', regionalText: 'অনিল দাস', isCorrect: false },
      ],
    },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [correctCount, setCorrectCount] = useState(0);
  const [errors, setErrors] = useState(0);
  const [feedback, setFeedback] = useState('');
  const [isCompleted, setIsCompleted] = useState(false);
  const [sessionScore, setSessionScore] = useState(0);

  const currentQ = questions[currentIndex];

  const handleSpeakQuestion = () => {
    speechService.speak(`${currentQ.regionalText}. ${currentQ.questionText}`, patient.language);
  };

  const handleSelectOption = (index: number) => {
    if (selectedIdx !== null) return;
    setSelectedIdx(index);
    const chosen = currentQ.options[index];

    if (chosen.isCorrect) {
      soundService.playSuccess();
      setCorrectCount((c) => c + 1);
      setFeedback('Wonderful! Exactly right.');
      speechService.speak(`${t.greatJob}! That is correct.`, patient.language);
    } else {
      soundService.playGentleHint();
      setErrors((e) => e + 1);
      const correctOne = currentQ.options.find((o) => o.isCorrect);
      setFeedback(`Good try! It is ${correctOne?.text}. You are doing wonderfully.`);
      speechService.speak(`Good effort. It is ${correctOne?.regionalText || correctOne?.text}.`, patient.language);
    }

    setTimeout(() => {
      if (currentIndex + 1 < questions.length) {
        setCurrentIndex((i) => i + 1);
        setSelectedIdx(null);
        setFeedback('');
      } else {
        handleFinish();
      }
    }, 2400);
  };

  const handleFinish = () => {
    setIsCompleted(true);
    const accuracy = Math.round((correctCount / questions.length) * 100);
    const finalScore = CognitiveEngine.calculateSessionScore('orientation_quiz', initialLevel, accuracy, 2000, errors);
    setSessionScore(finalScore);

    StorageService.addGameSession({
      id: `session-orient-${Date.now()}`,
      patientId: patient.id,
      gameType: 'orientation_quiz',
      level: initialLevel,
      accuracy,
      reactionTimeMs: 2200,
      errors,
      completed: true,
      timestamp: new Date().toISOString(),
      score: finalScore,
    });

    confetti({ particleCount: 50, spread: 60 });
    speechService.speak(`${t.wellDone}! You are well-oriented and calm.`, patient.language);
  };

  return (
    <div className="max-w-2xl mx-auto p-4 sm:p-6 animate-fadeIn">
      <div className="flex items-center justify-between gap-3 mb-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 bg-white hover:bg-slate-100 px-4 py-2.5 rounded-2xl border-2 border-slate-200 text-slate-800 font-bold shadow-sm transition active:scale-95 text-base sm:text-lg"
        >
          <ArrowLeft className="w-6 h-6 text-teal-700" />
          <span>{t.home}</span>
        </button>

        <div className="flex items-center gap-2 bg-teal-50 px-3.5 py-1.5 rounded-xl border border-teal-200">
          <span className="text-xs font-bold text-teal-700 uppercase">Question</span>
          <span className="text-lg font-black text-teal-900">{currentIndex + 1} / {questions.length}</span>
        </div>
      </div>

      {!isCompleted ? (
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border-2 border-teal-100 text-center">
          <div className="w-20 h-20 rounded-full bg-teal-50 border-4 border-teal-200 flex items-center justify-center text-4xl mx-auto mb-4">
            {currentQ.icon}
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mb-2">
            {currentQ.regionalText}
          </h2>
          <p className="text-base sm:text-lg text-slate-600 font-medium mb-4">
            {currentQ.questionText}
          </p>

          <button
            onClick={handleSpeakQuestion}
            className="inline-flex items-center gap-2 bg-teal-50 hover:bg-teal-100 border border-teal-200 text-teal-800 px-4 py-2 rounded-xl text-sm font-bold mb-6 transition"
          >
            <Volume2 className="w-4 h-4 text-teal-700" />
            <span>Hear Question Aloud</span>
          </button>

          <div className="space-y-3.5">
            {currentQ.options.map((opt, idx) => {
              const isSelected = selectedIdx === idx;
              let style = 'bg-white border-2 border-slate-300 text-slate-800 hover:border-teal-500 hover:bg-teal-50/50';

              if (selectedIdx !== null) {
                if (opt.isCorrect) {
                  style = 'bg-emerald-100 border-4 border-emerald-500 text-emerald-950 scale-102';
                } else if (isSelected && !opt.isCorrect) {
                  style = 'bg-amber-100 border-2 border-amber-400 text-amber-950 opacity-90';
                } else {
                  style = 'bg-slate-50 border border-slate-200 text-slate-400 opacity-60';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(idx)}
                  disabled={selectedIdx !== null}
                  className={`w-full py-4 px-6 rounded-2xl font-bold text-lg sm:text-xl text-left transition flex items-center justify-between shadow-xs ${style}`}
                >
                  <div className="flex flex-col">
                    <span className="font-extrabold text-slate-900">{opt.regionalText}</span>
                    <span className="text-sm font-medium text-slate-600">{opt.text}</span>
                  </div>
                  {selectedIdx !== null && opt.isCorrect && (
                    <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {feedback && (
            <div className="mt-5 p-3 rounded-2xl bg-teal-50 text-teal-900 font-bold text-base animate-fadeIn border border-teal-200">
              {feedback}
            </div>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border-2 border-teal-100 text-center animate-fadeIn">
          <div className="w-16 h-16 rounded-full bg-emerald-500 text-white flex items-center justify-center mx-auto mb-4 shadow-md">
            <Award className="w-9 h-9" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
            {t.wellDone}!
          </h2>
          <p className="text-base sm:text-lg text-slate-600 font-medium mt-1">
            You are in touch with today’s time, your home in {patient.location}, and your family.
          </p>
          <div className="my-6 inline-flex items-center gap-6 bg-teal-50 px-6 py-3 rounded-2xl border border-teal-200">
            <div>
              <span className="text-xs font-bold text-teal-700 uppercase">Orientation Score</span>
              <p className="text-3xl font-black text-teal-900">{sessionScore} / 100</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => {
                setCurrentIndex(0);
                setSelectedIdx(null);
                setCorrectCount(0);
                setErrors(0);
                setIsCompleted(false);
              }}
              className="bg-teal-700 hover:bg-teal-800 text-white px-6 py-3.5 rounded-2xl font-bold text-lg shadow-md transition"
            >
              Play Again
            </button>
            <button
              onClick={onBack}
              className="bg-amber-400 hover:bg-amber-500 text-slate-900 px-6 py-3.5 rounded-2xl font-bold text-lg shadow-sm transition"
            >
              Back to Home
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
