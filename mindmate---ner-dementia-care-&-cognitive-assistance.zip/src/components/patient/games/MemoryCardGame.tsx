import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { ArrowLeft, Sparkles, RotateCcw, Volume2, Award, Heart } from 'lucide-react';
import { PatientProfile, LanguageCode } from '../../../types';
import { soundService } from '../../../services/soundService';
import { speechService } from '../../../services/speechService';
import { StorageService } from '../../../services/storage';
import { CognitiveEngine } from '../../../services/cognitiveEngine';
import { translations } from '../../../utils/translations';

interface MemoryCardGameProps {
  patient: PatientProfile;
  onBack: () => void;
  initialLevel?: number;
}

interface CardItem {
  id: number;
  symbolId: string;
  name: string;
  regionalName: string;
  icon: string;
  description: string;
  isFlipped: boolean;
  isMatched: boolean;
}

// NER Regional Card Symbols
const REGIONAL_SYMBOLS = [
  { id: 'rhino', name: 'Kaziranga Rhino', regionalName: 'এশিঙীয়া গঁড়', icon: '🦏', desc: 'Famous one-horned rhino of Kaziranga National Park' },
  { id: 'gamosa', name: 'Assam Gamosa', regionalName: 'ফুলাম গামোচা', icon: '🧣', desc: 'Traditional red and white handwoven pride of Assam' },
  { id: 'tea', name: 'Assam Tea Garden', regionalName: 'চাহ বাগিচা', icon: '🍵', desc: 'World-renowned fragrant Assam orthodox tea' },
  { id: 'japi', name: 'Bihu Japi Hat', regionalName: 'বিহু জাপি', icon: '👒', desc: 'Conical bamboo hat adorned with red cloth' },
  { id: 'loktak', name: 'Loktak Floating Lake', regionalName: 'ল্লোকটাক পাত', icon: '🛶', desc: 'Manipur’s floating phumdis and freshwater sanctuary' },
  { id: 'hornbill', name: 'Hornbill Bird', regionalName: 'ধনেশ পক্ষী', icon: '🦜', desc: 'Sacred bird celebrated in Nagaland Hornbill festival' },
  { id: 'dhol', name: 'Bihu Dhol', regionalName: 'বিহু ঢোল', icon: '🥁', desc: 'Traditional drum beating the rhythm of Rongali Bihu' },
  { id: 'silk', name: 'Muga Golden Silk', regionalName: 'সোণালী মুগা', icon: '✨', desc: 'Ancient golden wild silk indigenous to Brahmaputra valley' },
];

export const MemoryCardGame: React.FC<MemoryCardGameProps> = ({ patient, onBack, initialLevel = 2 }) => {
  const [level, setLevel] = useState<number>(initialLevel);
  const [cards, setCards] = useState<CardItem[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [errors, setErrors] = useState(0);
  const [startTime, setStartTime] = useState<number>(Date.now());
  const [gameCompleted, setGameCompleted] = useState(false);
  const [sessionScore, setSessionScore] = useState<number>(0);

  const t = translations[patient.language] || translations.en;

  // Initialize cards according to level
  // Level 1: 2 pairs (4 cards)
  // Level 2: 3 pairs (6 cards)
  // Level 3: 4 pairs (8 cards)
  // Level 4: 5 pairs (10 cards)
  // Level 5: 6 pairs (12 cards)
  useEffect(() => {
    startNewGame(level);
  }, [level]);

  const startNewGame = (lvl: number) => {
    const pairCount = Math.min(REGIONAL_SYMBOLS.length, lvl + 1);
    const selectedSymbols = REGIONAL_SYMBOLS.slice(0, pairCount);

    const deck: CardItem[] = [];
    selectedSymbols.forEach((sym, idx) => {
      // Create pair
      deck.push({
        id: idx * 2,
        symbolId: sym.id,
        name: sym.name,
        regionalName: sym.regionalName,
        icon: sym.icon,
        description: sym.desc,
        isFlipped: false,
        isMatched: false,
      });
      deck.push({
        id: idx * 2 + 1,
        symbolId: sym.id,
        name: sym.name,
        regionalName: sym.regionalName,
        icon: sym.icon,
        description: sym.desc,
        isFlipped: false,
        isMatched: false,
      });
    });

    // Gentle shuffle
    const shuffled = [...deck].sort(() => Math.random() - 0.5);
    setCards(shuffled);
    setFlippedCards([]);
    setMoves(0);
    setErrors(0);
    setStartTime(Date.now());
    setGameCompleted(false);
  };

  const handleCardClick = (clickedId: number) => {
    if (flippedCards.length === 2) return; // Ignore while inspecting pair
    const card = cards.find((c) => c.id === clickedId);
    if (!card || card.isFlipped || card.isMatched) return;

    soundService.playGentleHint();

    // Flip this card
    const updatedCards = cards.map((c) => (c.id === clickedId ? { ...c, isFlipped: true } : c));
    setCards(updatedCards);

    const newFlipped = [...flippedCards, clickedId];
    setFlippedCards(newFlipped);

    // If 2 cards now flipped, check match
    if (newFlipped.length === 2) {
      setMoves((m) => m + 1);
      const card1 = updatedCards.find((c) => c.id === newFlipped[0])!;
      const card2 = updatedCards.find((c) => c.id === newFlipped[1])!;

      if (card1.symbolId === card2.symbolId) {
        // MATCH!
        setTimeout(() => {
          soundService.playSuccess();
          speechService.speak(`${card1.regionalName || card1.name}! Beautiful match!`, patient.language);

          const matchedCards = updatedCards.map((c) =>
            c.symbolId === card1.symbolId ? { ...c, isMatched: true, isFlipped: true } : c
          );
          setCards(matchedCards);
          setFlippedCards([]);

          // Check if all matched
          const allMatched = matchedCards.every((c) => c.isMatched);
          if (allMatched) {
            handleGameWin(matchedCards);
          }
        }, 500);
      } else {
        // Not a match - soft encouraging feedback, flip back gently
        setErrors((e) => e + 1);
        setTimeout(() => {
          setCards((prev) =>
            prev.map((c) => (newFlipped.includes(c.id) ? { ...c, isFlipped: false } : c))
          );
          setFlippedCards([]);
        }, 1200);
      }
    }
  };

  const handleGameWin = (finalCards: CardItem[]) => {
    const elapsedMs = Date.now() - startTime;
    const totalPairs = finalCards.length / 2;
    const accuracy = Math.max(40, Math.round((totalPairs / Math.max(totalPairs, moves + 1)) * 100));

    const finalScore = CognitiveEngine.calculateSessionScore(
      'memory_match',
      level,
      accuracy,
      elapsedMs,
      errors
    );

    setSessionScore(finalScore);
    setGameCompleted(true);

    // Save session to local storage
    StorageService.addGameSession({
      id: `session-mem-${Date.now()}`,
      patientId: patient.id,
      gameType: 'memory_match',
      level,
      accuracy,
      reactionTimeMs: Math.round(elapsedMs / Math.max(1, moves)),
      errors,
      completed: true,
      timestamp: new Date().toISOString(),
      score: finalScore,
    });

    // Celebration
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.6 },
    });

    speechService.speak(
      `${t.wellDone}! You matched all cards with great care. Score is ${finalScore}.`,
      patient.language
    );
  };

  const handleSpeakCard = (c: CardItem, e: React.MouseEvent) => {
    e.stopPropagation();
    speechService.speak(`${c.regionalName}. ${c.name}. ${c.description}`, patient.language);
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 animate-fadeIn">
      {/* Top Controls: Back button, Level indicator & encouragement */}
      <div className="flex items-center justify-between gap-2 mb-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 bg-white hover:bg-slate-100 px-4 py-2.5 rounded-2xl border-2 border-slate-200 text-slate-800 font-bold shadow-sm transition active:scale-95 text-base sm:text-lg"
        >
          <ArrowLeft className="w-6 h-6 text-teal-700" />
          <span>{t.home}</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold text-slate-600 hidden sm:inline">{t.level}:</span>
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map((lvl) => (
              <button
                key={lvl}
                onClick={() => setLevel(lvl)}
                className={`w-9 h-9 rounded-xl font-extrabold text-sm transition ${
                  level === lvl
                    ? 'bg-teal-700 text-white shadow-md ring-2 ring-amber-400'
                    : 'bg-white text-slate-700 border border-slate-200 hover:bg-teal-50'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={() => startNewGame(level)}
          className="p-2.5 rounded-2xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 transition"
          title="Restart game"
        >
          <RotateCcw className="w-5 h-5 text-teal-700" />
        </button>
      </div>

      {/* Game Title & Elderly-friendly prompt */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 mb-6 shadow-sm border-2 border-teal-100 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-3xl">🦏</span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              {t.memoryGame}
            </h1>
          </div>
          <p className="text-base sm:text-lg text-slate-600 mt-1 font-medium">
            Tap cards to turn them over and find matching pairs of North East symbols.
          </p>
        </div>

        <div className="flex items-center gap-3 bg-teal-50 px-4 py-2.5 rounded-2xl border border-teal-200">
          <div className="text-center">
            <span className="text-xs font-bold text-teal-700 uppercase">Pairs</span>
            <p className="text-xl font-black text-teal-900">{cards.filter((c) => c.isMatched).length / 2} / {cards.length / 2}</p>
          </div>
          <div className="w-px h-8 bg-teal-200" />
          <div className="text-center">
            <span className="text-xs font-bold text-teal-700 uppercase">Tries</span>
            <p className="text-xl font-black text-teal-900">{moves}</p>
          </div>
        </div>
      </div>

      {/* Card Grid - Large tap targets (min 48px, accessible font) */}
      <div
        className={`grid gap-3 sm:gap-4 ${
          cards.length <= 4
            ? 'grid-cols-2 max-w-md mx-auto'
            : cards.length <= 6
            ? 'grid-cols-2 sm:grid-cols-3 max-w-xl mx-auto'
            : cards.length <= 8
            ? 'grid-cols-2 sm:grid-cols-4 max-w-2xl mx-auto'
            : 'grid-cols-3 sm:grid-cols-4 max-w-3xl mx-auto'
        }`}
      >
        {cards.map((card) => (
          <button
            key={card.id}
            onClick={() => handleCardClick(card.id)}
            disabled={card.isMatched || card.isFlipped}
            className={`h-36 sm:h-44 rounded-3xl p-3 flex flex-col items-center justify-center text-center transition-all duration-300 transform active:scale-95 shadow-md relative ${
              card.isMatched
                ? 'bg-emerald-50 border-4 border-emerald-400 opacity-90'
                : card.isFlipped
                ? 'bg-white border-4 border-teal-500 scale-102'
                : 'bg-gradient-to-br from-[#0D5C75] to-[#14728F] border-4 border-teal-600 hover:brightness-110'
            }`}
          >
            {card.isFlipped || card.isMatched ? (
              <div className="flex flex-col items-center justify-center animate-fadeIn">
                <span className="text-4xl sm:text-5xl mb-1">{card.icon}</span>
                <span className="text-base sm:text-lg font-black text-slate-900 leading-tight">
                  {card.regionalName}
                </span>
                <span className="text-xs text-slate-600 font-semibold line-clamp-1">
                  {card.name}
                </span>

                {card.isMatched && (
                  <span className="absolute top-2 right-2 bg-emerald-500 text-white rounded-full p-1">
                    <Heart className="w-3.5 h-3.5 fill-current" />
                  </span>
                )}

                <button
                  onClick={(e) => handleSpeakCard(card, e)}
                  className="absolute bottom-2 right-2 p-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700"
                  title="Speak"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center">
                {/* Traditional motif design on back */}
                <div className="w-14 h-14 rounded-2xl bg-teal-800/80 flex items-center justify-center text-amber-300 font-black text-2xl border border-teal-600/50">
                  🌺
                </div>
                <span className="mt-2 text-xs font-bold text-teal-100 tracking-wider">
                  MINDMATE
                </span>
              </div>
            )}
          </button>
        ))}
      </div>

      {/* Completion Modal / Celebration */}
      {gameCompleted && (
        <div className="mt-8 bg-emerald-50 border-4 border-emerald-300 rounded-3xl p-6 text-center animate-fadeIn shadow-lg">
          <div className="w-16 h-16 rounded-full bg-emerald-500 text-white flex items-center justify-center mx-auto mb-3 shadow-md">
            <Award className="w-9 h-9" />
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-emerald-900">
            {t.greatJob}
          </h2>
          <p className="text-lg font-medium text-emerald-800 mt-1 max-w-md mx-auto">
            {t.wellDone} You exercised your visual memory beautifully.
          </p>

          <div className="my-5 inline-flex items-center gap-6 bg-white px-6 py-3 rounded-2xl shadow-xs border border-emerald-200">
            <div>
              <span className="text-xs font-bold text-slate-500 uppercase">Session Score</span>
              <p className="text-3xl font-black text-teal-800">{sessionScore} / 100</p>
            </div>
            <div className="w-px h-10 bg-slate-200" />
            <div>
              <span className="text-xs font-bold text-slate-500 uppercase">Next Level</span>
              <p className="text-2xl font-black text-amber-600">Level {Math.min(5, level + 1)}</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => {
                setLevel((l) => Math.min(5, l + 1));
                startNewGame(Math.min(5, level + 1));
              }}
              className="bg-teal-700 hover:bg-teal-800 text-white px-6 py-3.5 rounded-2xl font-bold text-lg shadow-md transition active:scale-95"
            >
              Play Next Level
            </button>
            <button
              onClick={() => startNewGame(level)}
              className="bg-white hover:bg-slate-100 text-slate-800 border-2 border-slate-300 px-6 py-3.5 rounded-2xl font-bold text-lg transition"
            >
              Play Again
            </button>
            <button
              onClick={onBack}
              className="bg-amber-400 hover:bg-amber-500 text-slate-900 px-6 py-3.5 rounded-2xl font-bold text-lg shadow-sm transition"
            >
              Back to Home
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
