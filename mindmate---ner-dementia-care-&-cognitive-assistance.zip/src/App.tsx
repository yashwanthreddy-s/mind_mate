import React, { useState, useEffect } from 'react';
import { Role, LanguageCode, GameType, PatientProfile } from './types';
import { StorageService } from './services/storage';
import { Header } from './components/common/Header';
import { SOSModal } from './components/common/SOSModal';
import { OfflineBanner } from './components/common/OfflineBanner';
import { PatientHome } from './components/patient/PatientHome';
import { DailyRoutineView } from './components/patient/DailyRoutineView';
import { FamilyAlbumView } from './components/patient/FamilyAlbumView';
import { MemoryCardGame } from './components/patient/games/MemoryCardGame';
import { NameObjectGame } from './components/patient/games/NameObjectGame';
import { SequenceRecallGame } from './components/patient/games/SequenceRecallGame';
import { OrientationQuizGame } from './components/patient/games/OrientationQuizGame';
import { FolkMusicGame } from './components/patient/games/FolkMusicGame';
import { CaregiverDashboard } from './components/caregiver/CaregiverDashboard';
import { AshaDashboard } from './components/asha/AshaDashboard';
import { RoleSelectorModal } from './components/auth/RoleSelectorModal';
import { translations } from './utils/translations';

export default function App() {
  const [isInitialized, setIsInitialized] = useState(false);
  const [currentRole, setCurrentRole] = useState<Role>('patient');
  const [patients, setPatients] = useState<PatientProfile[]>([]);
  const [activePatientId, setActivePatientId] = useState<string>('p1');
  const [currentLanguage, setCurrentLanguage] = useState<LanguageCode>('as');
  const [currentView, setCurrentView] = useState<string>('home');
  const [activeGame, setActiveGame] = useState<GameType | null>(null);
  const [isSOSOpen, setIsSOSOpen] = useState(false);
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false);

  useEffect(() => {
    StorageService.init().then(() => {
      const all = StorageService.getPatients();
      setPatients(all);
      const activeId = StorageService.getActivePatientId();
      setActivePatientId(activeId);
      const activeP = all.find((p) => p.id === activeId) || all[0];
      if (activeP) {
        setCurrentLanguage(activeP.language);
      }
      setIsInitialized(true);
    });
  }, []);

  const activePatient = patients.find((p) => p.id === activePatientId) || patients[0];

  const handleSelectPatient = (id: string) => {
    setActivePatientId(id);
    StorageService.setActivePatientId(id);
    const p = patients.find((item) => item.id === id);
    if (p) {
      setCurrentLanguage(p.language);
    }
  };

  const handleLanguageChange = (lang: LanguageCode) => {
    setCurrentLanguage(lang);
    if (activePatient) {
      const updated = { ...activePatient, language: lang };
      StorageService.updatePatient(updated);
      setPatients(StorageService.getPatients());
    }
  };

  const handleUpdatePatient = (updated: PatientProfile) => {
    StorageService.updatePatient(updated);
    setPatients(StorageService.getPatients());
  };

  const handleNavigate = (view: string) => {
    setCurrentView(view);
    setActiveGame(null);
  };

  const handleLaunchGame = (gameType: GameType) => {
    setActiveGame(gameType);
    setCurrentView('game-playing');
  };

  const handleBackToPatientHome = () => {
    setActiveGame(null);
    setCurrentView('home');
    setPatients(StorageService.getPatients());
  };

  if (!isInitialized || !activePatient) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#FAF8F5] text-slate-800 p-4">
        <div className="w-16 h-16 rounded-3xl bg-teal-800 text-white flex items-center justify-center text-3xl font-black mb-4 animate-pulse">
          M
        </div>
        <p className="text-xl font-extrabold text-teal-900">Initializing MindMate...</p>
        <p className="text-sm text-slate-500 mt-1">Dementia Care for North East India (SIH26003)</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-slate-800 font-sans selection:bg-teal-100 selection:text-teal-900">
      {/* Offline Connectivity Banner */}
      <OfflineBanner />

      {/* Main Accessible Header */}
      <Header
        currentRole={currentRole}
        onRoleChange={(role) => {
          setCurrentRole(role);
          setCurrentView('home');
          setActiveGame(null);
        }}
        activePatient={activePatient}
        allPatients={patients}
        onSelectPatient={handleSelectPatient}
        currentLanguage={currentLanguage}
        onLanguageChange={handleLanguageChange}
        onTriggerSOS={() => setIsSOSOpen(true)}
        onNavigate={handleNavigate}
        currentView={currentView}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-16">
        {currentRole === 'patient' && (
          <>
            {activeGame === 'memory_match' && (
              <MemoryCardGame
                patient={activePatient}
                onBack={handleBackToPatientHome}
                initialLevel={2}
              />
            )}
            {activeGame === 'name_object' && (
              <NameObjectGame
                patient={activePatient}
                onBack={handleBackToPatientHome}
                initialLevel={1}
              />
            )}
            {activeGame === 'sequence_recall' && (
              <SequenceRecallGame
                patient={activePatient}
                onBack={handleBackToPatientHome}
                initialLevel={2}
              />
            )}
            {activeGame === 'orientation_quiz' && (
              <OrientationQuizGame
                patient={activePatient}
                onBack={handleBackToPatientHome}
                initialLevel={1}
              />
            )}
            {activeGame === 'folk_music' && (
              <FolkMusicGame
                patient={activePatient}
                onBack={handleBackToPatientHome}
                initialLevel={1}
              />
            )}

            {!activeGame && currentView === 'home' && (
              <PatientHome
                patient={activePatient}
                onNavigateToGame={handleLaunchGame}
                onNavigateToRoutine={() => setCurrentView('routine')}
                onNavigateToFamily={() => setCurrentView('family')}
                onTriggerSOS={() => setIsSOSOpen(true)}
              />
            )}

            {!activeGame && currentView === 'games' && (
              <div className="max-w-4xl mx-auto p-4 sm:p-6 animate-fadeIn">
                <PatientHome
                  patient={activePatient}
                  onNavigateToGame={handleLaunchGame}
                  onNavigateToRoutine={() => setCurrentView('routine')}
                  onNavigateToFamily={() => setCurrentView('family')}
                  onTriggerSOS={() => setIsSOSOpen(true)}
                />
              </div>
            )}

            {!activeGame && currentView === 'routine' && (
              <DailyRoutineView
                patient={activePatient}
                onBack={handleBackToPatientHome}
              />
            )}

            {!activeGame && currentView === 'family' && (
              <FamilyAlbumView
                patient={activePatient}
                onBack={handleBackToPatientHome}
              />
            )}
          </>
        )}

        {currentRole === 'caregiver' && (
          <CaregiverDashboard
            patient={activePatient}
            allPatients={patients}
            onSelectPatient={handleSelectPatient}
            onUpdatePatient={handleUpdatePatient}
          />
        )}

        {currentRole === 'asha' && (
          <AshaDashboard
            allPatients={patients}
            onSelectPatient={handleSelectPatient}
            onViewPatientAsCaregiver={(patientId) => {
              handleSelectPatient(patientId);
              setCurrentRole('caregiver');
            }}
          />
        )}
      </main>

      {/* Emergency SOS Reassurance Modal */}
      <SOSModal
        isOpen={isSOSOpen}
        onClose={() => setIsSOSOpen(false)}
        patient={activePatient}
      />

      {/* Role Switcher Dialog */}
      <RoleSelectorModal
        isOpen={isRoleModalOpen}
        onClose={() => setIsRoleModalOpen(false)}
        currentRole={currentRole}
        onSelectRole={(role) => {
          setCurrentRole(role);
          setCurrentView('home');
          setActiveGame(null);
        }}
      />

      {/* Footer with Hackathon & Accessibility Credential */}
      <footer className="border-t border-slate-200 bg-white py-6 px-4 text-center text-xs text-slate-500 font-medium">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-teal-800">MindMate NER</span>
            <span>•</span>
            <span>SIH26003 (Team Algo-X)</span>
            <span>•</span>
            <span>Dementia Cognitive Care Platform</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsRoleModalOpen(true)}
              className="text-teal-700 font-bold hover:underline"
            >
              Switch Demo Accounts
            </button>
            <span>•</span>
            <span>Assam • Mizoram • Manipur</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
